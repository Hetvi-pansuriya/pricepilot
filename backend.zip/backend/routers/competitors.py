"""
routers/competitors.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: REST API endpoints for managing competitor entries and scraping.

Endpoints:
  POST   /companies/{id}/competitors                        → add competitor URL + trigger scrape
  GET    /companies/{id}/competitors                        → list all competitors for a company
  PATCH  /companies/{id}/competitors/{comp_id}/manual      → manually paste competitor pricing text
  DELETE /companies/{id}/competitors/{comp_id}             → delete a competitor entry

WHY PATCH for manual text? PATCH means "partial update" — we're only changing
the scraped text fields, not replacing the entire competitor object (that would be PUT).

CONNECTED TO:
  - main.py      → router mounted at prefix="/companies"
  - models.py    → Competitor model (competitors table)
  - schemas.py   → CompetitorCreate, CompetitorResponse, ManualCompetitorText
  - auth.py      → get_current_user dependency
  - scraper.py   → scrape_competitor() and _clean_pricing_content() used here
  - analysis.py  → reads clean_scraped_text from DB for module3 benchmarking
─────────────────────────────────────────────────────────────────────────────
"""

# uuid: for UUID path parameters and generating new competitor IDs.
import uuid

# datetime: for recording when a competitor was created.
from datetime import datetime

# List: type hint for list-returning endpoints.
from typing import List

# APIRouter: creates the router for competitor endpoints.
# BackgroundTasks: FastAPI's built-in mechanism for running tasks AFTER the response is sent.
#   WHY BackgroundTasks? Web scraping can take 5–40 seconds. We don't want the frontend
#   to hang waiting — instead we return 201 immediately and scrape in the background.
# HTTPException: raises HTTP error responses.
# status: HTTP status code constants.
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, status

# AsyncSession: async database session type.
from sqlalchemy.ext.asyncio import AsyncSession

# select: builds SQL SELECT queries.
from sqlalchemy.future import select

# get_db: FastAPI dependency that provides a DB session per request.
from database import get_db

# Company, Competitor, User: the DB models this router interacts with.
# CONNECTED TO: models.py
from models import Company, Competitor, User

# Pydantic schemas for request/response validation.
# CompetitorCreate: request body for adding a competitor (validates URL format).
# CompetitorResponse: response shape for competitor data.
# ManualCompetitorText: request body for pasting competitor text manually.
# CONNECTED TO: schemas.py
from schemas import CompetitorCreate, CompetitorResponse, ManualCompetitorText

# get_current_user: authenticates the request using JWT Bearer token.
# CONNECTED TO: auth.py
from routers.auth import get_current_user

# scrape_competitor: the main async scraper function (tries Layer1 then Layer2).
# _clean_pricing_content: cleans raw text by removing noise (used for manual text too).
# CONNECTED TO: scraper.py
from scraper import _clean_pricing_content, scrape_competitor

# Create the router. main.py mounts it with prefix="/companies" so all routes
# become: /companies/{company_id}/competitors/...
router = APIRouter()

# Maximum competitors per company.
# WHY limit? Playwright (Layer 2 scraping) uses a real Chrome browser — 10+ concurrent
# browsers would consume enormous memory and slow down the server significantly.
MAX_COMPETITORS = 5


# ─── Helper Functions ─────────────────────────────────────────────────────────

async def _assert_company_owner(company_id, user, db):
    """Verify the given user owns the given company. Raises 404 if not found."""
    # This is a security check: ensures users can only access their own companies' competitors.
    # We intentionally return 404 (not 403) to avoid revealing that a company exists.
    result = await db.execute(
        select(Company).where(Company.id == company_id, Company.user_id == user.id)
    )
    company = result.scalar_one_or_none()  # None if not found or not owned by user
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")
    return company  # the Company model object (used by callers if needed)


async def _run_scrape_and_save(competitor_id: uuid.UUID, url: str):
    """Background task: scrape a competitor URL and save the result to the DB.
    
    Called via FastAPI's BackgroundTasks after the 201 response is already sent.
    Uses its own DB session (AsyncSessionLocal) since the request session is closed.
    """
    # Import here to avoid circular imports at module load time.
    # database.AsyncSessionLocal: the session factory (not the request-scoped session).
    # WHY import here? _run_scrape_and_save runs as a background task AFTER the request
    # is complete — we need a NEW database session since the request's session is closed.
    from database import AsyncSessionLocal

    # Run the scraper (may take 5–40 seconds for Playwright).
    # result is a dict: {"text": "...", "clean_text": "...", "status": "success_layer1"}
    result = await scrape_competitor(url)

    # Open a new DB session just for saving the scrape result.
    # "async with AsyncSessionLocal() as db:" → auto-closes session on exit.
    async with AsyncSessionLocal() as db:
        # Look up the competitor row by ID.
        q = await db.execute(select(Competitor).where(Competitor.id == competitor_id))
        comp = q.scalar_one_or_none()  # None if deleted while scraping was in progress

        if comp:
            # Update the competitor row with the scraped content.
            comp.raw_scraped_text = result["text"]                    # full raw text (up to 12,000 chars)
            comp.clean_scraped_text = result.get("clean_text", "")   # noise-filtered text (up to 8,000 chars)
            comp.scrape_status = result["status"]                     # e.g., "success_layer1", "manual_required"
            await db.commit()  # save all 3 column updates to PostgreSQL


# ─── Endpoints ────────────────────────────────────────────────────────────────

# POST /companies/{company_id}/competitors — Add a competitor URL
# Returns 201 immediately; scraping runs in the background.
# CONNECTED TO: frontend CompanySetup.jsx "Add Competitor" form submits to this.
@router.post("/{company_id}/competitors", response_model=CompetitorResponse, status_code=status.HTTP_201_CREATED)
async def add_competitor(
    company_id: uuid.UUID,                               # company UUID from URL path
    body: CompetitorCreate,                              # contains validated URL (AnyHttpUrl)
    background_tasks: BackgroundTasks,                   # FastAPI background task runner
    current_user: User = Depends(get_current_user),      # authenticated user
    db: AsyncSession = Depends(get_db),                  # database session
):
    # Verify ownership — raises 404 if company doesn't exist or belongs to another user.
    await _assert_company_owner(company_id, current_user, db)

    # Check if the company already has 5 competitors.
    # We query all competitors for this company and count them.
    # WHY not SELECT COUNT(*)? To avoid another query pattern — just get all IDs.
    count_result = await db.execute(
        select(Competitor).where(Competitor.company_id == company_id)
    )
    if len(count_result.scalars().all()) >= MAX_COMPETITORS:
        # 400 Bad Request: user hit the limit.
        raise HTTPException(
            status_code=400,
            detail=f"Maximum {MAX_COMPETITORS} competitors allowed per company"
        )

    # Convert AnyHttpUrl object to a plain string for DB storage.
    # Pydantic's AnyHttpUrl validates the URL is valid but returns a URL object, not str.
    # The Competitor model stores url as String (VARCHAR) — must be plain string.
    url_str = str(body.url)

    # Create the Competitor record in "pending" state.
    # scrape_status="pending" → frontend shows a loading spinner until scraping finishes.
    competitor = Competitor(
        id=uuid.uuid4(),                   # new UUID
        company_id=company_id,             # link to parent company
        url=url_str,                       # the competitor's pricing page URL
        scrape_status="pending",           # initial status before scraping runs
        created_at=datetime.utcnow(),      # creation timestamp
    )
    db.add(competitor)         # stage for INSERT
    await db.commit()          # execute INSERT (competitor now exists in DB)
    await db.refresh(competitor)  # reload to get the generated id

    # Schedule the scrape as a background task.
    # FastAPI will call _run_scrape_and_save() AFTER the 201 response is sent to the client.
    # competitor.id → needed to find the row in DB and save the result.
    # url_str → the URL to scrape.
    # WHY background? Scraping takes 5–40 seconds — don't make the user wait.
    background_tasks.add_task(_run_scrape_and_save, competitor.id, url_str)

    # Return the competitor immediately (with scrape_status="pending").
    # Frontend will poll or refresh to see the updated scrape_status.
    return competitor


# GET /companies/{company_id}/competitors — List all competitors for a company
# CONNECTED TO: frontend CompanySetup.jsx loads this to show scrape status indicators.
@router.get("/{company_id}/competitors", response_model=List[CompetitorResponse])
async def list_competitors(
    company_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _assert_company_owner(company_id, current_user, db)  # ownership check

    # Fetch all competitors for this company (no pagination — max 5 anyway).
    result = await db.execute(
        select(Competitor).where(Competitor.company_id == company_id)
    )
    return result.scalars().all()  # list of Competitor model objects → serialized as CompetitorResponse


# PATCH /companies/{company_id}/competitors/{competitor_id}/manual — Paste competitor text manually
# Used when: scraping fails (JavaScript-only page), or user has private pricing not on the website.
# WHY PATCH? We're partially updating — only the scraped text fields, not the URL or name.
# CONNECTED TO: frontend shows a "Paste manually" option when scrape_status is "manual_required".
@router.patch("/{company_id}/competitors/{competitor_id}/manual", response_model=CompetitorResponse)
async def set_manual_text(
    company_id: uuid.UUID,
    competitor_id: uuid.UUID,
    body: ManualCompetitorText,   # contains the pasted text (min_length=1)
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _assert_company_owner(company_id, current_user, db)  # ownership check

    # Find the specific competitor (must match both competitor_id AND company_id).
    result = await db.execute(
        select(Competitor).where(
            Competitor.id == competitor_id,
            Competitor.company_id == company_id  # prevents cross-company access
        )
    )
    competitor = result.scalar_one_or_none()

    if not competitor:
        raise HTTPException(status_code=404, detail="Competitor not found")

    # Save the manually pasted text as raw_scraped_text.
    competitor.raw_scraped_text = body.text  # full pasted text (no length limit enforced here)

    # Also run the noise-filtering cleaner on the manually pasted text.
    # _clean_pricing_content: removes navigation, legal, duplicate lines from the text.
    # CONNECTED TO: scraper.py exports this function specifically for this use case.
    competitor.clean_scraped_text = _clean_pricing_content(body.text)

    # Mark as manually entered so the frontend stops showing the "scrape failed" UI.
    competitor.scrape_status = "manual"  # distinct from "success_layer1" or "success_layer2"

    await db.commit()          # save all 3 fields
    await db.refresh(competitor)  # reload from DB
    return competitor  # serialized as CompetitorResponse


# DELETE /companies/{company_id}/competitors/{competitor_id} — Remove a competitor
# CONNECTED TO: frontend CompanySetup.jsx delete button on each competitor entry.
@router.delete("/{company_id}/competitors/{competitor_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_competitor(
    company_id: uuid.UUID,
    competitor_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _assert_company_owner(company_id, current_user, db)  # ownership check

    # Find the competitor (must match both IDs — prevents deleting other companies' competitors).
    result = await db.execute(
        select(Competitor).where(
            Competitor.id == competitor_id,
            Competitor.company_id == company_id  # security: company ownership
        )
    )
    comp = result.scalar_one_or_none()

    if not comp:
        raise HTTPException(status_code=404, detail="Competitor not found")

    await db.delete(comp)  # delete the competitor row
    await db.commit()      # execute DELETE
    # 204 No Content response (no body)
