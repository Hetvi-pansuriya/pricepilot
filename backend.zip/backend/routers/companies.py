"""
routers/companies.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: REST API endpoints for managing companies, pricing tiers, and features.

Endpoints:
  POST   /companies                              → create a new company
  GET    /companies                              → list all user's companies
  GET    /companies/{id}                         → get company with tiers+features+competitors
  PUT    /companies/{id}                         → update company name/industry/description
  DELETE /companies/{id}                         → delete company + all related data
  POST   /companies/{id}/tiers                   → add a new pricing tier
  PUT    /companies/{id}/tiers/{tid}             → update an existing tier
  DELETE /companies/{id}/tiers/{tid}             → delete a tier
  POST   /companies/{id}/tiers/{tid}/features    → add a feature to a tier
  DELETE /companies/{id}/tiers/{tid}/features/{fid} → delete a feature

CONNECTED TO:
  - main.py      → registers this router with prefix="/companies"
  - models.py    → Company, PricingTier, Feature database models
  - schemas.py   → Pydantic validation schemas for requests/responses
  - auth.py      → get_current_user dependency for authentication
  - database.py  → get_db dependency for DB sessions
─────────────────────────────────────────────────────────────────────────────
"""

# uuid: for generating unique IDs and parsing UUID path parameters.
import uuid

# datetime: for recording creation timestamps on new records.
from datetime import datetime

# List: type hint for endpoints that return multiple items.
from typing import List

# APIRouter: creates a mountable sub-application with all company routes.
# Depends: FastAPI dependency injection (DB sessions, auth).
# HTTPException: raises HTTP error responses (404 Not Found, 409 Conflict, etc.)
# status: HTTP status code constants (201 Created, 204 No Content, etc.)
from fastapi import APIRouter, Depends, HTTPException, status

# AsyncSession: type hint for the async database session.
from sqlalchemy.ext.asyncio import AsyncSession

# select: builds SQL SELECT queries in Python.
# Example: select(Company).where(Company.id == some_uuid)
from sqlalchemy.future import select

# selectinload: SQLAlchemy eager loading strategy.
# Instead of N+1 queries, loads all related objects in ONE additional query.
# Example: selectinload(Company.tiers) → loads all tiers for a company in one SQL query.
# WHY eager loading? Without it, accessing company.tiers would trigger a lazy load
# which fails in async context (async sessions don't support lazy loading).
from sqlalchemy.orm import selectinload

# func: SQL functions (like func.lower() for case-insensitive comparison).
from sqlalchemy import func

# get_db: provides a DB session per request (from database.py).
from database import get_db

# SQLAlchemy model classes for the 5 database tables this router touches.
# CONNECTED TO: models.py defines these classes.
from models import Company, PricingTier, Feature, Competitor, User

# Pydantic schemas for request body validation and response serialization.
# CONNECTED TO: schemas.py defines these.
from schemas import (
    CompanyCreate, CompanyResponse, CompanyDetailResponse,  # company-level schemas
    TierCreate, TierResponse,                                # tier-level schemas
    FeatureCreate, FeatureResponse,                          # feature-level schemas
)

# get_current_user: FastAPI dependency that extracts and validates the JWT token.
# Returns the authenticated User object. Raises 401 if token is invalid/missing.
# CONNECTED TO: auth.py
from routers.auth import get_current_user

# Create the router — all @router.xxx decorators below register routes here.
# main.py mounts this with: app.include_router(companies.router, prefix="/companies")
router = APIRouter()

# Maximum number of competitors allowed per company.
# Defined here (same value as in competitors.py) to keep the limit consistent.
# WHY limit? Scraping too many competitors is slow and expensive (Playwright browser launches).
MAX_COMPETITORS = 5


# ─── Helper Functions ─────────────────────────────────────────────────────────
# These helpers reduce code duplication across endpoint functions.

async def get_company_or_404(company_id: uuid.UUID, user: User, db: AsyncSession) -> Company:
    """Fetch a company by ID and user ownership, with all tiers/features/competitors eager-loaded.
    Raises 404 if the company doesn't exist or belongs to a different user."""
    result = await db.execute(
        select(Company)
        # WHERE: company matches the ID AND belongs to the current user.
        # The user.id check prevents User A from accessing User B's companies.
        .where(Company.id == company_id, Company.user_id == user.id)
        # Eager loading: load tiers AND each tier's features in separate SQL queries.
        # Without this, accessing company.tiers.features raises MissingGreenlet in async context.
        .options(
            selectinload(Company.tiers).selectinload(PricingTier.features),  # tiers + their features
            selectinload(Company.competitors),  # all competitor entries for this company
        )
    )
    company = result.scalar_one_or_none()  # returns Company or None

    if not company:
        # 404: company not found OR user doesn't own it (we give the same error for security).
        raise HTTPException(status_code=404, detail="Company not found")

    return company  # the Company model object with tiers/features/competitors loaded


async def get_tier_or_404(tier_id: uuid.UUID, company_id: uuid.UUID, db: AsyncSession) -> PricingTier:
    """Fetch a tier by ID and company ownership. Raises 404 if not found."""
    result = await db.execute(
        select(PricingTier)
        # Both conditions must match: correct tier_id AND belongs to the correct company.
        # Prevents accessing tiers from other companies.
        .where(PricingTier.id == tier_id, PricingTier.company_id == company_id)
        .options(selectinload(PricingTier.features))  # also load features for response
    )
    tier = result.scalar_one_or_none()

    if not tier:
        raise HTTPException(status_code=404, detail="Tier not found")

    return tier  # the PricingTier model object with features loaded


async def verify_company_ownership(company_id: uuid.UUID, user: User, db: AsyncSession) -> Company:
    """Lightweight ownership check without loading related data. Raises 404 if not found."""
    # WHY lighter version (no selectinload)? Some endpoints just need to verify ownership
    # without needing tier/competitor data — avoid unnecessary DB queries.
    result = await db.execute(
        select(Company).where(Company.id == company_id, Company.user_id == user.id)
    )
    company = result.scalar_one_or_none()

    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    return company  # returns Company model (no tiers/competitors loaded)


# ─── Company CRUD Endpoints ───────────────────────────────────────────────────

# POST /companies — Create a new company
# response_model=CompanyResponse → FastAPI validates and serializes the return value.
# status_code=201 → "Created" (more semantic than 200 for resource creation).
# CONNECTED TO: schemas.CompanyCreate (request), schemas.CompanyResponse (response),
#               models.Company (DB table).
@router.post("", response_model=CompanyResponse, status_code=status.HTTP_201_CREATED)
async def create_company(
    body: CompanyCreate,                           # validated request body
    current_user: User = Depends(get_current_user),  # authenticated user
    db: AsyncSession = Depends(get_db),            # database session
):
    # Create a new Company model instance with all fields.
    company = Company(
        id=uuid.uuid4(),          # generate a new random UUID
        user_id=current_user.id,  # link to the authenticated user
        name=body.name,           # company name from request body (1–100 chars)
        industry=body.industry,   # industry type (e.g., "saas_b2b")
        description=body.description,  # optional description
        created_at=datetime.utcnow(),   # record creation timestamp
    )
    db.add(company)       # stage for INSERT
    await db.commit()     # execute INSERT to PostgreSQL
    await db.refresh(company)  # reload from DB to get any DB-generated fields
    return company  # FastAPI converts this to JSON using CompanyResponse schema


# GET /companies — List all companies for the current user
# CONNECTED TO: frontend Dashboard.jsx fetches this on load.
@router.get("", response_model=List[CompanyResponse])
async def list_companies(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # SELECT only companies belonging to the current user.
    # WHY always filter by user_id? Prevents any risk of data leakage between users.
    result = await db.execute(
        select(Company).where(Company.user_id == current_user.id)
    )
    return result.scalars().all()  # returns list of Company objects (serialized as CompanyResponse)


# GET /companies/{company_id} — Get a single company with ALL nested data
# Returns company + its tiers (with features) + its competitors.
# CONNECTED TO: frontend CompanySetup.jsx fetches this to show the setup form.
@router.get("/{company_id}", response_model=CompanyDetailResponse)
async def get_company(
    company_id: uuid.UUID,  # parsed from URL path parameter (FastAPI auto-converts string → UUID)
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # get_company_or_404 loads company + tiers + features + competitors.
    # CompanyDetailResponse schema includes nested tiers and competitors.
    return await get_company_or_404(company_id, current_user, db)


# DELETE /companies/{company_id} — Delete a company and all its data
# CASCADE in models.py auto-deletes: tiers, features, competitors, sessions, reports.
# status_code=204 → No Content (success with no body — standard for DELETE).
@router.delete("/{company_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_company(
    company_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Fetch with ownership check (no selectinload needed — just deleting).
    result = await db.execute(
        select(Company).where(Company.id == company_id, Company.user_id == current_user.id)
    )
    company = result.scalar_one_or_none()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    await db.delete(company)  # marks the row for deletion
    await db.commit()         # executes DELETE (CASCADE handles all related rows)
    # 204 No Content → FastAPI sends empty body automatically


# PUT /companies/{company_id} — Update company name/industry/description
# Uses CompanyCreate for the body (same validation rules as create).
# CONNECTED TO: frontend EditCompanyModal or settings page.
@router.put("/{company_id}", response_model=CompanyResponse)
async def update_company(
    company_id: uuid.UUID,
    body: CompanyCreate,  # reuse CompanyCreate schema for update (same fields)
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Company).where(
            Company.id == company_id,
            Company.user_id == current_user.id,  # ownership check
        )
    )
    company = result.scalar_one_or_none()
    if not company:
        raise HTTPException(status_code=404, detail="Company not found")

    # Update only the fields that came in the request body.
    # SQLAlchemy tracks these changes and commits them in one UPDATE statement.
    company.name = body.name
    company.industry = body.industry
    company.description = body.description

    await db.commit()         # executes UPDATE
    await db.refresh(company) # reload from DB to confirm saved values
    return company


# ─── Pricing Tier Endpoints ──────────────────────────────────────────────────

# POST /companies/{company_id}/tiers — Add a new pricing tier to a company
# CONNECTED TO: frontend CompanySetup.jsx "Add Tier" button calls this.
@router.post("/{company_id}/tiers", response_model=TierResponse, status_code=status.HTTP_201_CREATED)
async def add_tier(
    company_id: uuid.UUID,
    body: TierCreate,  # tier name, price, billing_cycle, user_count, churn_rate
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Ownership check (lightweight — no selectinload needed for adding a tier).
    await verify_company_ownership(company_id, current_user, db)

    # Create the PricingTier model instance.
    tier = PricingTier(
        id=uuid.uuid4(),                       # new UUID
        company_id=company_id,                 # link to the parent company
        name=body.name,                        # e.g., "Basic"
        price=body.price,                      # e.g., 49.0
        billing_cycle=body.billing_cycle,      # "monthly" or "annual"
        user_count=body.user_count,            # e.g., 200
        churn_rate=body.churn_rate,            # e.g., 0.05 (optional)
        created_at=datetime.utcnow(),          # creation timestamp
    )
    db.add(tier)      # stage for INSERT
    await db.commit() # execute INSERT

    # Re-fetch the tier with features loaded (to satisfy TierResponse.features field).
    # WHY re-fetch? After commit(), the tier object doesn't have features loaded.
    # We must query again with selectinload to get the features relationship.
    result2 = await db.execute(
        select(PricingTier)
        .where(PricingTier.id == tier.id)
        .options(selectinload(PricingTier.features))  # load features (empty for new tier)
    )
    return result2.scalar_one()  # return the re-fetched tier (includes features=[])


# PUT /companies/{company_id}/tiers/{tier_id} — Update a pricing tier
# WHY this endpoint exists: users often need to adjust prices or user counts after creation.
@router.put("/{company_id}/tiers/{tier_id}", response_model=TierResponse)
async def update_tier(
    company_id: uuid.UUID,
    tier_id: uuid.UUID,
    body: TierCreate,  # same schema as create (all fields required for PUT)
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await verify_company_ownership(company_id, current_user, db)  # check user owns the company
    tier = await get_tier_or_404(tier_id, company_id, db)         # get tier or 404

    # Update all tier fields from the request body.
    tier.name = body.name
    tier.price = body.price
    tier.billing_cycle = body.billing_cycle
    tier.user_count = body.user_count
    tier.churn_rate = body.churn_rate

    await db.commit()     # execute UPDATE
    await db.refresh(tier) # reload from DB

    # Re-fetch with features to return a complete TierResponse.
    result = await db.execute(
        select(PricingTier)
        .where(PricingTier.id == tier_id)
        .options(selectinload(PricingTier.features))
    )
    return result.scalar_one()


# DELETE /companies/{company_id}/tiers/{tier_id} — Delete a pricing tier
# CASCADE in models.py auto-deletes all Feature rows for this tier.
@router.delete("/{company_id}/tiers/{tier_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_tier(
    company_id: uuid.UUID,
    tier_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await verify_company_ownership(company_id, current_user, db)  # ownership check
    tier = await get_tier_or_404(tier_id, company_id, db)          # get tier or 404

    await db.delete(tier)  # delete the tier (CASCADE deletes all its features)
    await db.commit()      # execute DELETE
    # 204 No Content response


# ─── Feature Endpoints ────────────────────────────────────────────────────────

# POST /companies/{company_id}/tiers/{tier_id}/features — Add a feature to a tier
# CONNECTED TO: frontend CompanySetup.jsx "Add Feature" button.
@router.post(
    "/{company_id}/tiers/{tier_id}/features",
    response_model=FeatureResponse,
    status_code=status.HTTP_201_CREATED,
)
async def add_feature(
    company_id: uuid.UUID,
    tier_id: uuid.UUID,
    body: FeatureCreate,  # feature_name (required), description (optional)
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await verify_company_ownership(company_id, current_user, db)  # check user owns company

    # Verify the tier exists and belongs to this company (prevents adding features to wrong tiers).
    result2 = await db.execute(
        select(PricingTier).where(PricingTier.id == tier_id, PricingTier.company_id == company_id)
    )
    if not result2.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Tier not found")

    # Duplicate feature check within the same tier.
    # func.lower() → case-insensitive comparison in PostgreSQL SQL.
    # Prevents "API Access" and "api access" from both existing in the same tier.
    # WHY 409 Conflict? It's a semantic conflict — the same resource already exists.
    dup = await db.execute(
        select(Feature).where(
            Feature.tier_id == tier_id,
            func.lower(Feature.feature_name) == func.lower(body.feature_name)  # case-insensitive
        )
    )
    if dup.scalar_one_or_none():
        raise HTTPException(
            status_code=409,  # 409 Conflict — resource already exists
            detail=f"Feature '{body.feature_name}' already exists in this tier"
        )

    # Create the Feature model instance.
    feature = Feature(
        id=uuid.uuid4(),               # new UUID
        tier_id=tier_id,               # link to the parent tier
        feature_name=body.feature_name,  # e.g., "API Access"
        description=body.description,  # optional description (may be None)
    )
    db.add(feature)         # stage for INSERT
    await db.commit()       # execute INSERT
    await db.refresh(feature)  # reload from DB
    return feature  # serialized as FeatureResponse (id, feature_name, description)


# DELETE /companies/{company_id}/tiers/{tier_id}/features/{feature_id} — Remove a feature
# CONNECTED TO: frontend CompanySetup.jsx feature delete button.
@router.delete(
    "/{company_id}/tiers/{tier_id}/features/{feature_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_feature(
    company_id: uuid.UUID,
    tier_id: uuid.UUID,
    feature_id: uuid.UUID,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await verify_company_ownership(company_id, current_user, db)  # ownership check

    # Find the feature: must match both feature_id AND tier_id.
    # Prevents deleting features from other tiers via URL manipulation.
    result = await db.execute(
        select(Feature).where(Feature.id == feature_id, Feature.tier_id == tier_id)
    )
    feature = result.scalar_one_or_none()

    if not feature:
        raise HTTPException(status_code=404, detail="Feature not found")

    await db.delete(feature)  # delete the feature row
    await db.commit()         # execute DELETE
    # 204 No Content response
