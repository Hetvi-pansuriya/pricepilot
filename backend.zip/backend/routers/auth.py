"""
auth.py (routers/auth.py)
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Handles all user authentication endpoints.

Endpoints:
  POST /auth/signup           → create new account, return JWT
  POST /auth/login            → verify credentials, return JWT
  POST /auth/forgot-password  → send password reset email
  POST /auth/reset-password   → validate token, set new password
  DELETE /auth/account        → delete user account and all their data

Also exports: get_current_user() — a FastAPI dependency used by ALL other
routers to authenticate requests via the JWT Bearer token.

CONNECTED TO:
  - main.py       → registers this router with prefix="/auth"
  - database.py   → uses get_db() dependency for DB sessions
  - models.py     → queries User and PasswordResetToken models
  - schemas.py    → uses UserCreate, LoginRequest, TokenResponse, etc.
  - All other routers import get_current_user from here for auth checks.
─────────────────────────────────────────────────────────────────────────────
"""

# os: reads environment variables (JWT_SECRET, JWT_ALGORITHM, etc. from .env)
import os

# secrets: Python standard library for cryptographically secure random values.
# Used to generate unguessable password reset tokens.
import secrets

# uuid: for generating unique user IDs when creating a new account.
import uuid

# datetime: for token expiry calculation (current time + N hours).
# timedelta: represents a time duration (e.g., timedelta(hours=24) = 24 hours).
from datetime import datetime, timedelta

# Optional: type hint for values that can be None (e.g., missing JWT token).
from typing import Optional

# APIRouter: creates a sub-application that can be mounted at a prefix in main.py.
# Depends: FastAPI's dependency injection — used to inject DB sessions and auth.
# HTTPException: raises HTTP error responses (e.g., 401 Unauthorized, 409 Conflict).
# Request: gives access to the full HTTP request (headers, query params, app.state, etc.)
# status: HTTP status code constants (status.HTTP_201_CREATED = 201, etc.)
from fastapi import APIRouter, Depends, HTTPException, Request, status

# HTTPBearer: parses the "Authorization: Bearer <token>" header from requests.
# HTTPAuthorizationCredentials: the object containing the extracted token string.
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

# jwt: JSON Web Token library. Used to encode/decode JWT tokens.
# JWTError: raised when a token is invalid, expired, or tampered with.
from jose import JWTError, jwt

# CryptContext: manages password hashing with bcrypt.
# bcrypt is a deliberately slow hash — makes brute-force attacks impractical.
from passlib.context import CryptContext

# AsyncSession: async database session type (for type hints).
from sqlalchemy.ext.asyncio import AsyncSession

# select: SQLAlchemy query builder for SELECT statements.
# Example: select(User).where(User.email == "x@y.com")
from sqlalchemy.future import select

# get_db: the FastAPI dependency that provides a DB session per request.
# CONNECTED TO: database.py
from database import get_db

# PasswordResetToken, User: the DB table models we query.
# CONNECTED TO: models.py
from models import PasswordResetToken, User

# Import all the Pydantic schemas used in this file as request/response types.
# CONNECTED TO: schemas.py
from schemas import (
    UserCreate,          # POST /signup request body
    LoginRequest,        # POST /login and /forgot-password request body
    ResetPasswordBody,   # POST /reset-password request body
    UserResponse,        # used in get_current_user return type hint
    TokenResponse,       # returned by /signup and /login
)

# Create the router — all endpoints defined with @router.post/@router.get
# will be registered when main.py does: app.include_router(auth.router, prefix="/auth")
router = APIRouter()

# ─── Config ───────────────────────────────────────────────────────────────────
# Read JWT configuration from environment variables (set in .env file).

# SECRET_KEY: the secret used to sign JWTs. MUST be kept private.
# If an attacker knows this, they can forge valid tokens.
# "changeme-very-secret-key" is a fallback for dev — ALWAYS override in .env for production.
SECRET_KEY = os.getenv("JWT_SECRET", "changeme-very-secret-key")
                       
# ALGORITHM: which cryptographic algorithm to use for signing JWTs.
# HS256 = HMAC with SHA-256. Symmetric — same key for signing and verifying.
# Alternative: RS256 (asymmetric) — uses public/private key pair.
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# EXPIRE_HOURS: how long a JWT is valid after it's issued.
# int(): converts the string from os.getenv to an integer.
# 24 hours default → users stay logged in for 24 hours before needing to re-login.
EXPIRE_HOURS = int(os.getenv("JWT_EXPIRE_HOURS", "24"))

# pwd_context: the bcrypt password hashing context.
# schemes=["bcrypt"] → use bcrypt as the hashing algorithm.
# deprecated="auto" → automatically upgrade old hashes if needed.
# CONNECTED TO: hash_password() and verify_password() functions use this.
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# security: extracts the Bearer token from the Authorization header.
# auto_error=False → if no token is found, return None instead of raising 401.
# WHY False? get_current_user also checks query params (for SSE requests that can't set headers).
security = HTTPBearer(auto_error=False)


# ─── Helper Functions ──────────────────────────────────────────────────────────

# hash_password: converts a plain text password into a bcrypt hash.
# Returns: a string like "$2b$12$..." (the bcrypt hash).
# CONNECTED TO: signup() calls this to store the password safely in the DB.
def hash_password(password: str) -> str:
    return pwd_context.hash(password)  # bcrypt hash with random salt


# verify_password: checks if a plain password matches a stored bcrypt hash.
# Returns: True if they match, False otherwise.
# CONNECTED TO: login() calls this to authenticate the user.
def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)  # bcrypt comparison (timing-safe)


# create_access_token: creates a JWT token for a given user ID.
# JWT Structure: {header}.{payload}.{signature}
# The payload (body) contains: sub (user ID) and exp (expiry timestamp).
# WHY "sub"? "sub" is the standard JWT claim for the subject (user being identified).
# CONNECTED TO: signup() and login() call this to issue the token on success.
def create_access_token(user_id: uuid.UUID) -> str:
    payload = {
        "sub": str(user_id),  # subject: the user's UUID as a string
        "exp": datetime.utcnow() + timedelta(hours=EXPIRE_HOURS),  # expiry: now + 24h
    }
    # jwt.encode: sign the payload with the secret key using HS256.
    # Returns a JWT token string like: "eyJhbGc..."
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


# ─── Dependency: get_current_user ─────────────────────────────────────────────
# This is the MOST IMPORTANT function in auth.py.
# It's a FastAPI dependency used by EVERY protected endpoint across all routers.
# Usage in other files: current_user: User = Depends(get_current_user)
#
# HOW IT WORKS:
#   1. FastAPI extracts the Bearer token from the Authorization header (via HTTPBearer).
#   2. Also checks the "token" query parameter (for SSE requests which can't set headers).
#   3. Decodes and verifies the JWT using the secret key.
#   4. Looks up the user in the DB by the "sub" (user ID) from the JWT.
#   5. Returns the User object → used in the endpoint function.
#   6. If ANYTHING fails, raises 401 Unauthorized.
#
# CONNECTED TO: analysis.py, companies.py, competitors.py all import and use this.
# Re-declared here (removing duplicate at line 33) for clarity.
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer(auto_error=False)  # re-declared for clarity (same as above)

async def get_current_user(
    request: Request,  # full request object — used to check query params for token
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),  # Bearer header
    db: AsyncSession = Depends(get_db),  # DB session for user lookup
) -> User:
    # Get the token from the Authorization header OR the "token" query parameter.
    # credentials.credentials → the token string from "Authorization: Bearer <token>"
    # request.query_params.get("token") → fallback for SSE requests (can't set headers in browser EventSource)
    token = credentials.credentials if credentials else request.query_params.get("token")
    
    # Standard 401 exception — reused multiple times below.
    # WWW-Authenticate: "Bearer" tells the client what auth scheme is required.
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},  # standard response header for 401
    )

    try:
        if not token:
            # No token provided at all (no Authorization header, no query param).
            raise credentials_exception

        # Decode and verify the JWT.
        # jwt.decode: checks the signature (using SECRET_KEY) and expiry.
        # If the token is expired, tampered with, or invalid → raises JWTError.
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])

        # Extract the user ID from the "sub" (subject) claim.
        # .get("sub") → returns None if the claim is missing.
        user_id: Optional[str] = payload.get("sub")

        if user_id is None:
            # Token is valid but has no user ID — shouldn't happen but guard anyway.
            raise credentials_exception

    except JWTError:
        # Token is expired, has an invalid signature, or is malformed.
        raise credentials_exception

    # Look up the user in the database by the UUID from the token.
    # uuid.UUID(user_id): convert the string "4aee0518-..." back to a UUID object.
    # scalar_one_or_none(): returns the User if found, or None if not found.
    result = await db.execute(select(User).where(User.id == uuid.UUID(user_id)))
    user = result.scalar_one_or_none()

    if user is None:
        # Token is valid but the user no longer exists (e.g., account was deleted).
        raise credentials_exception

    # Return the authenticated User object — available as current_user in the endpoint.
    return user


# ─── Endpoints ────────────────────────────────────────────────────────────────

# POST /auth/signup
# Creates a new user account and returns a JWT token immediately (auto-login on signup).
# response_model=TokenResponse → FastAPI validates the return value matches TokenResponse.
# status_code=201 → "Created" (more specific than 200 for resource creation).
# CONNECTED TO: schemas.UserCreate (request), schemas.TokenResponse (response),
#               models.User (DB write), hash_password() (password hashing).
@router.post("/signup", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def signup(body: UserCreate, db: AsyncSession = Depends(get_db)):
    # Check if email already exists — prevent duplicate accounts.
    result = await db.execute(select(User).where(User.email == body.email))
    existing = result.scalar_one_or_none()  # returns User or None

    if existing:
        # 409 Conflict: the email is already taken.
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email already registered",
        )

    # Create a new User model instance with the provided data.
    user = User(
        id=uuid.uuid4(),                           # generate a new random UUID
        email=body.email,                          # the validated email from the request body
        password_hash=hash_password(body.password),  # bcrypt-hash the password before storing
        created_at=datetime.utcnow(),              # record the registration timestamp
    )
    db.add(user)       # stage the new user row for insertion
    await db.commit()  # execute the INSERT to PostgreSQL
    await db.refresh(user)  # reload the user from DB (populates any DB-generated fields)

    # Create and return a JWT token for immediate login.
    token = create_access_token(user.id)
    return TokenResponse(access_token=token)  # returns {"access_token": "eyJ...", "token_type": "bearer"}


# POST /auth/login
# Verifies credentials and returns a JWT token if correct.
# CONNECTED TO: schemas.LoginRequest (request), schemas.TokenResponse (response).
@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    # Find user by email.
    result = await db.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()  # None if email not found

    # Check: user must exist AND password must match.
    # WHY combine both checks in one condition?
    # If we return "email not found" separately, attackers can enumerate registered emails.
    # A single generic "Invalid email or password" prevents that information leak.
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",  # intentionally vague
        )

    # Issue a JWT token for this user.
    token = create_access_token(user.id)
    return TokenResponse(access_token=token)


# POST /auth/forgot-password
# Initiates the password reset flow. Always returns success (prevents email enumeration).
# CONNECTED TO: schemas.LoginRequest (reused just for email field), PasswordResetToken model,
#               email_service.py (sends the actual email).
@router.post("/forgot-password", status_code=status.HTTP_200_OK)
async def forgot_password(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Always return success to prevent account enumeration."""
    # Prepare the success message returned in ALL cases (even if email doesn't exist).
    # WHY? If we returned "email not found" when the email isn't registered, 
    # attackers could enumerate which emails are in our system.
    message = {"message": "If this email exists, a reset link has been sent."}

    # Look up the user — if not found, return the generic success message anyway.
    result = await db.execute(select(User).where(User.email == body.email))
    user = result.scalar_one_or_none()
    if not user:
        return message  # don't reveal that the email isn't registered

    # Delete any existing reset tokens for this user (prevent token accumulation).
    old_tokens = await db.execute(
        select(PasswordResetToken).where(PasswordResetToken.user_id == user.id)
    )
    for old_token in old_tokens.scalars().all():
        await db.delete(old_token)  # remove each old token

    # Generate a new cryptographically secure random token.
    # secrets.token_urlsafe(32): 32 bytes of random data, URL-safe base64 encoded.
    # Result is a 43-character string safe to use in URLs.
    token = secrets.token_urlsafe(32)

    # Save the reset token to the DB with a 1-hour expiry.
    db.add(
        PasswordResetToken(
            id=uuid.uuid4(),                              # new UUID for this token row
            user_id=user.id,                             # links to the user
            token=token,                                  # the random token string
            expires_at=datetime.utcnow() + timedelta(hours=1),  # 1 hour from now
        )
    )
    await db.commit()  # save the token to the DB

    # Build the full reset link sent in the email.
    # FRONTEND_URL from .env: the deployed frontend base URL.
    # rstrip("/"): removes trailing slash to avoid double slashes in the URL.
    # /reset-password?token=<token>: the frontend route that handles password reset.
    reset_link = (
        f"{os.getenv('FRONTEND_URL', 'http://localhost:5173').rstrip('/')}"
        f"/reset-password?token={token}"
    )

    # Attempt to send the reset email. Non-fatal — server continues even if email fails.
    try:
        from email_service import send_password_reset_email  # optional module
        await send_password_reset_email(user.email, reset_link)
    except Exception as error:
        # Log the error but don't fail the request — the token is still valid in the DB.
        print(f"[Email] Reset email failed (non-fatal): {error}")

    return message  # always return success regardless of email delivery


# POST /auth/reset-password
# Validates the reset token and updates the user's password.
# CONNECTED TO: schemas.ResetPasswordBody (request), PasswordResetToken model, User model.
@router.post("/reset-password", status_code=status.HTTP_200_OK)
async def reset_password(
    body: ResetPasswordBody,       # contains "token" and "new_password"
    db: AsyncSession = Depends(get_db),
):
    # Look up the reset token in the DB.
    result = await db.execute(
        select(PasswordResetToken).where(PasswordResetToken.token == body.token)
    )
    reset = result.scalar_one_or_none()  # None if token doesn't exist

    # Validate the token — reject if:
    # 1. Not found in DB (never issued or already deleted)
    # 2. Already used (used == "yes") — prevents replay attacks
    # 3. Expired (current time is past expires_at)
    if (
        not reset
        or reset.used == "yes"
        or reset.expires_at < datetime.utcnow()
    ):
        raise HTTPException(
            status_code=400,
            detail="Invalid or expired reset link.",
        )

    # Look up the user associated with this token.
    user_result = await db.execute(select(User).where(User.id == reset.user_id))
    user = user_result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found.")  # shouldn't happen

    # Update the user's password hash with the new password.
    user.password_hash = hash_password(body.new_password)  # bcrypt the new password

    # Mark the token as used so it can't be used again.
    reset.used = "yes"

    await db.commit()  # save both changes to the DB in one transaction
    return {"message": "Password updated successfully."}


# DELETE /auth/account
# Deletes the current user's account and ALL their data (companies, tiers, reports, etc.)
# Due to CASCADE foreign keys in models.py, deleting the User cascades to everything.
# CONNECTED TO: models.py User.companies cascade="all, delete-orphan".
@router.delete("/account", status_code=status.HTTP_204_NO_CONTENT)
async def delete_account(
    current_user: User = Depends(get_current_user),  # must be authenticated
    db: AsyncSession = Depends(get_db),
):
    # Re-fetch the user from DB (get_current_user already did this, but we need
    # a fresh instance in THIS session to call db.delete() on it).
    result = await db.execute(select(User).where(User.id == current_user.id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    await db.delete(user)  # mark for deletion (CASCADE will handle all related data)
    await db.commit()      # execute the DELETE — all user data is permanently removed
    # 204 No Content → success, no response body (FastAPI handles this automatically)
