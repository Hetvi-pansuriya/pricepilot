"""
schemas.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Defines Pydantic "schemas" — data shapes for API request bodies
         and API response bodies.

WHY Pydantic schemas? Three reasons:
  1. VALIDATION: FastAPI auto-validates incoming JSON against these schemas.
     If the frontend sends an invalid email or missing field, FastAPI returns
     a 422 error before the route function even runs.
  2. SERIALIZATION: Pydantic converts SQLAlchemy model objects into JSON
     for API responses (enabled by model_config = {"from_attributes": True}).
  3. DOCUMENTATION: FastAPI uses these schemas to auto-generate the /docs
     Swagger UI with correct request/response shapes.

DIFFERENCE between schemas.py and models.py:
  - models.py  → defines DATABASE tables (SQLAlchemy, talks to PostgreSQL)
  - schemas.py → defines API contract (Pydantic, talks to the frontend)
  They are separate so DB internals (like password_hash) are never exposed in API.

CONNECTED TO:
  - All 4 routers import from here as parameter/response types.
  - FastAPI uses these for validation and documentation automatically.
─────────────────────────────────────────────────────────────────────────────
"""

# BaseModel: the parent class for all Pydantic models.
# Pydantic reads the class attributes and their type annotations to know 
# what fields to expect and how to validate them.
# EmailStr: a Pydantic type that validates strings are valid email addresses.
#   "notanemail" → validation error. "user@example.com" → passes.
# Field: lets you add extra validation rules beyond just the type.
#   Field(min_length=6) means the string must be at least 6 characters.
# field_validator: decorator for custom validation logic (e.g., strip whitespace).
# AnyHttpUrl: validates the value is a valid HTTP or HTTPS URL.
#   "notaurl" → fails. "https://example.com" → passes.
from pydantic import BaseModel, EmailStr, Field, field_validator, AnyHttpUrl

# Optional: type hint meaning the value can be the given type OR None (null).
# List: type hint for a list of items of a given type.
# Any: type hint meaning "any Python type" — used for json_report (could be dict or list).
from typing import Optional, List, Any

# datetime: used as a type hint for timestamp fields in response schemas.
# When Pydantic serializes a datetime, it becomes an ISO 8601 string in JSON.
# Example: datetime(2026, 6, 29, 5, 37) → "2026-06-29T05:37:00"
from datetime import datetime

# uuid: used as a type hint for ID fields.
# When Pydantic serializes a uuid.UUID, it becomes a UUID string in JSON.
# Example: UUID("4aee0518...") → "4aee0518-6c22-424b-b073-d85d33c7ce9d"
import uuid


# ══════════════════════════════════════════════════════════════
# SECTION 1: AUTH SCHEMAS
# ══════════════════════════════════════════════════════════════

# UserCreate: the shape of the POST /auth/signup request body.
# Frontend sends: {"email": "user@example.com", "password": "secret123"}
# CONNECTED TO: auth.py signup() receives body: UserCreate
class UserCreate(BaseModel):
    email: EmailStr          # must be a valid email format
    password: str = Field(min_length=6)  # password must be at least 6 characters
    # WHY min_length=6? Prevents trivially weak passwords like "abc".


# LoginRequest: the shape of the POST /auth/login request body.
# WHY separate from UserCreate? UserCreate has min_length=6 on password.
# If we used UserCreate for login and someone typed the wrong password (< 6 chars),
# they'd get a 422 Validation Error instead of a 401 Unauthorized.
# That's confusing — wrong password should be 401, not 422.
# FIX: Separate schema with no min_length on password for login.
# CONNECTED TO: auth.py login() and forgot_password() use this schema.
class LoginRequest(BaseModel):
    email: EmailStr    # validated email format
    password: str      # no min_length — let auth logic handle wrong passwords


# UserResponse: the shape of the user object returned by /auth/signup.
# We return this instead of the User model directly so password_hash is NEVER exposed.
# model_config = {"from_attributes": True} → tells Pydantic to read data from
#   SQLAlchemy model attributes (not just dicts). Required for ORM integration.
# CONNECTED TO: auth.py signup() returns TokenResponse (not UserResponse directly).
class UserResponse(BaseModel):
    id: uuid.UUID           # user's UUID
    email: EmailStr         # user's email
    created_at: datetime    # registration timestamp
    model_config = {"from_attributes": True}  # allows creating from SQLAlchemy User model


# TokenResponse: returned by /auth/signup and /auth/login on success.
# access_token: the JWT string the frontend must include in all subsequent requests.
# token_type: always "bearer" — the HTTP Authorization header format: "Bearer <token>"
# CONNECTED TO: auth.py create_access_token() generates the JWT, returned here.
class TokenResponse(BaseModel):
    access_token: str           # the JWT token string
    token_type: str = "bearer"  # default value — always "bearer"


# ResetPasswordBody: the shape of the POST /auth/reset-password request body.
# token: the URL-safe string from the password reset email link.
# new_password: the new password to set (min 6 chars same as signup).
# CONNECTED TO: auth.py reset_password() receives this.
class ResetPasswordBody(BaseModel):
    token: str                               # the reset token from the email URL
    new_password: str = Field(min_length=6)  # minimum 6 characters for new password


# ══════════════════════════════════════════════════════════════
# SECTION 2: COMPANY SCHEMAS
# ══════════════════════════════════════════════════════════════

# CompanyCreate: request body for POST /companies (create a new company).
# Field constraints: min_length ensures no blank strings, max_length prevents huge inputs.
# CONNECTED TO: companies.py create_company() receives body: CompanyCreate.
class CompanyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)  # company name (1–100 chars)
    industry: str = Field(min_length=1)               # industry category (required)
    description: Optional[str] = Field(default=None, max_length=500)  # optional (up to 500 chars)


# CompanyResponse: what /companies returns when listing or getting a company.
# Never exposes user_id — that's an internal FK not needed by the frontend.
# model_config from_attributes=True → read from SQLAlchemy Company model object.
# CONNECTED TO: companies.py create_company(), get_companies(), get_company() return this.
class CompanyResponse(BaseModel):
    id: uuid.UUID            # company's UUID
    name: str                # company name
    industry: str            # industry category
    description: Optional[str]  # optional description (None if not set)
    created_at: datetime     # when company was created
    model_config = {"from_attributes": True}


# ══════════════════════════════════════════════════════════════
# SECTION 3: PRICING TIER SCHEMAS
# ══════════════════════════════════════════════════════════════

# TierCreate: request body for POST /companies/{id}/tiers (add a pricing tier).
# ge=0 → "greater than or equal to 0" — prevents negative prices or user counts.
# pattern=... → regex that only accepts "monthly" or "annual" for billing_cycle.
# CONNECTED TO: companies.py create_tier() receives body: TierCreate.
class TierCreate(BaseModel):
    name: str = Field(min_length=1, max_length=50)   # tier name (e.g., "Basic")
    price: float = Field(ge=0)                        # price in USD (must be ≥ 0)
    billing_cycle: str = Field(default="monthly", pattern="^(monthly|annual)$")  # only these two values
    user_count: int = Field(ge=0, default=0)          # current subscribers (must be ≥ 0)
    churn_rate: Optional[float] = Field(default=None, ge=0, le=1)  # 0.0–1.0, optional


# FeatureResponse: one feature item in a TierResponse's features list.
# CONNECTED TO: TierResponse.features uses List[FeatureResponse].
class FeatureResponse(BaseModel):
    id: uuid.UUID           # feature's UUID
    feature_name: str       # e.g., "API Access"
    description: Optional[str]  # optional description
    model_config = {"from_attributes": True}  # read from SQLAlchemy Feature model


# TierResponse: returned when listing or creating tiers.
# features: List[FeatureResponse] → includes nested feature list for each tier.
# CONNECTED TO: companies.py create_tier(), list_tiers() return this.
class TierResponse(BaseModel):
    id: uuid.UUID               # tier's UUID
    company_id: uuid.UUID       # which company this tier belongs to
    name: str                   # tier name (e.g., "Growth")
    price: float                # price in USD
    billing_cycle: str          # "monthly" or "annual"
    user_count: int             # current subscriber count
    churn_rate: Optional[float] # monthly churn rate (0.0–1.0) or None
    created_at: datetime        # when tier was created
    features: List[FeatureResponse] = []  # list of features (empty by default)
    model_config = {"from_attributes": True}


# ══════════════════════════════════════════════════════════════
# SECTION 4: FEATURE SCHEMAS
# ══════════════════════════════════════════════════════════════

# FeatureCreate: request body for POST /companies/{id}/tiers/{tid}/features.
# Uses a custom validator (field_validator) to strip whitespace from feature_name.
# Example: "  API Access  " → "API Access" after stripping.
# WHY strip? Users sometimes accidentally add spaces; this handles it gracefully.
# CONNECTED TO: companies.py create_feature() receives body: FeatureCreate.
class FeatureCreate(BaseModel):
    feature_name: str = Field(min_length=1, max_length=100)  # 1–100 chars
    description: Optional[str] = Field(default=None, max_length=300)  # optional, up to 300 chars

    # @field_validator: runs this method every time feature_name is set.
    # @classmethod: Pydantic requires validators to be class methods.
    # mode defaults to "after" (runs after type validation).
    # v: str → the value being validated.
    @field_validator("feature_name")
    @classmethod
    def strip_feature_name(cls, v: str) -> str:
        stripped = v.strip()          # remove leading/trailing whitespace
        if not stripped:              # if only whitespace was given, it's now empty
            raise ValueError("feature_name cannot be blank")  # Pydantic converts this to 422
        return stripped               # return the cleaned value


# ══════════════════════════════════════════════════════════════
# SECTION 5: COMPETITOR SCHEMAS
# ══════════════════════════════════════════════════════════════

# CompetitorCreate: request body for POST /companies/{id}/competitors (add competitor URL).
# AnyHttpUrl validates the URL starts with http:// or https://.
# The field_validator converts the AnyHttpUrl object back to a plain string
# because the DB stores it as a String column.
# CONNECTED TO: competitors.py create_competitor() receives body: CompetitorCreate.
class CompetitorCreate(BaseModel):
    url: AnyHttpUrl  # must be a valid HTTP/HTTPS URL

    # Runs BEFORE type validation (mode="before"). Converts any input to a string first.
    # WHY? AnyHttpUrl might be passed as a Pydantic URL object or plain string.
    # Ensuring it's a string makes downstream handling consistent.
    @field_validator("url", mode="before")
    @classmethod
    def ensure_string(cls, v):
        return str(v) if not isinstance(v, str) else v  # convert to str if not already


# ManualCompetitorText: request body for POST /companies/{id}/competitors/{comp_id}/manual-text.
# When scraping fails, the user can paste competitor pricing text manually.
# min_length=1 ensures they can't paste an empty string.
# CONNECTED TO: competitors.py paste_manual_text() receives body: ManualCompetitorText.
class ManualCompetitorText(BaseModel):
    text: str = Field(min_length=1)  # the pasted competitor pricing text


# CompetitorResponse: returned when listing competitors for a company.
# Note: raw_scraped_text is NOT included here — it can be huge (12,000 chars).
# Only clean_scraped_text (8,000 chars max) is exposed via the API.
# CONNECTED TO: competitors.py list_competitors(), create_competitor() return this.
class CompetitorResponse(BaseModel):
    id: uuid.UUID           # competitor's UUID
    company_id: uuid.UUID   # which company this competitor belongs to
    name: Optional[str]     # optional competitor name (None if user didn't set it)
    url: str                # competitor's pricing page URL
    scrape_status: str      # current scrape state (pending/success/failed/etc.)
    clean_scraped_text: Optional[str] = None  # cleaned scraped content (may be None)
    created_at: datetime    # when competitor was added
    model_config = {"from_attributes": True}  # read from SQLAlchemy Competitor model


# ══════════════════════════════════════════════════════════════
# SECTION 6: ANALYSIS SCHEMAS
# ══════════════════════════════════════════════════════════════

# AnalysisStartResponse: returned immediately when POST /analysis/start/{company_id} is called.
# The session_id is used by the frontend to poll /analysis/progress/{session_id}.
# CONNECTED TO: analysis.py start_analysis() returns this, frontend uses session_id for SSE.
class AnalysisStartResponse(BaseModel):
    session_id: uuid.UUID   # the UUID of the newly created AnalysisSession


# ProgressUpdate: the shape of each SSE (Server-Sent Event) message during analysis.
# Sent by the /analysis/progress/{session_id} SSE stream as the analysis runs.
# CONNECTED TO: analysis.py push() function sends these updates, frontend reads them.
class ProgressUpdate(BaseModel):
    progress: int                        # 0–100 (percentage complete)
    status: str                          # e.g., "running", "m1_m2_complete", "completed"
    report_id: Optional[uuid.UUID] = None  # only present in the final 100% update


# ReportResponse: returned by GET /analysis/report/{session_id}.
# json_report: Any → can be a dict (the full analysis JSON), type varies so we use Any.
# pdf_path: Optional — may be None if PDF generation failed.
# CONNECTED TO: analysis.py get_report() returns this, frontend reads json_report for charts.
class ReportResponse(BaseModel):
    id: uuid.UUID           # report's UUID
    session_id: uuid.UUID   # which analysis session this report belongs to
    json_report: Any        # full analysis dict {company, module1_revenue, ..., module4_recommendations}
    pdf_path: Optional[str] # file path to PDF (None if unavailable)
    created_at: datetime    # when report was saved
    model_config = {"from_attributes": True}  # read from SQLAlchemy Report model


# AnalysisHistoryItem: one item in the list returned by GET /analysis/history/{company_id}.
# Shows past analysis runs — when they started, their status, and the report_id to view them.
# CONNECTED TO: analysis.py analysis_history() returns List[AnalysisHistoryItem].
class AnalysisHistoryItem(BaseModel):
    session_id: uuid.UUID        # the session's UUID (used to fetch report)
    status: str                  # "completed", "partial", "failed", "running"
    progress: int                # 0–100
    started_at: datetime         # when analysis was kicked off
    completed_at: Optional[datetime]    # when it finished (None if still running)
    report_id: Optional[uuid.UUID]     # the Report UUID (None if not yet saved)
    model_config = {"from_attributes": True}


# ══════════════════════════════════════════════════════════════
# SECTION 7: COMPANY DETAIL (nested relations)
# ══════════════════════════════════════════════════════════════

# CompanyDetailResponse: a rich company response that includes tiers AND competitors.
# Returned by GET /companies/{id} — the full company view with all nested data.
# tiers: List[TierResponse] → each tier includes its features (nested 2 levels deep).
# competitors: List[CompetitorResponse] → all competitors with their scrape status.
# CONNECTED TO: companies.py get_company() returns this (with eager loading in DB query).
class CompanyDetailResponse(BaseModel):
    id: uuid.UUID                       # company's UUID
    name: str                           # company name
    industry: str                       # industry category
    description: Optional[str]          # optional description
    created_at: datetime                # creation timestamp
    tiers: List[TierResponse] = []      # all pricing tiers (each with features inside)
    competitors: List[CompetitorResponse] = []  # all competitor entries
    model_config = {"from_attributes": True}    # read from SQLAlchemy Company model
