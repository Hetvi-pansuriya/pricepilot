# ─── models.py ───────────────────────────────────────────────────────────────
# PURPOSE: Defines all database table structures as Python classes.
#          Each class = one table in PostgreSQL. SQLAlchemy maps Python objects
#          to rows in the database automatically.
# CONNECTED TO: database.py (imports Base), schemas.py (mirrors these for API),
#               every router file (queries these models to read/write data).
# ─────────────────────────────────────────────────────────────────────────────

# uuid: Python standard library for generating universally unique IDs (UUIDs).
# UUIDs look like: "4aee0518-6c22-424b-b073-d85d33c7ce9d"
# WHY UUIDs instead of 1,2,3...? They are random, unpredictable, and globally unique —
# users can't guess other users' IDs, which improves security.
import uuid

# datetime: used to record timestamps (when a row was created, when analysis completed, etc.)
from datetime import datetime

# Import SQLAlchemy column types. Each Column(...) call defines one column in the database table.
# Column     → base class for all columns
# String     → VARCHAR — stores text up to a certain length (emails, names, etc.)
# Float      → stores decimal numbers (prices like 49.99)
# Integer    → stores whole numbers (user_count like 200)
# Text       → stores long, unlimited text (scraped competitor pages, PDF paths)
# DateTime   → stores date+time values (created_at, completed_at)
# ForeignKey → links one table to another (like company_id in PricingTier links to companies table)
# JSON       → stores any JSON data (used to store the full analysis report dict)
from sqlalchemy import (
    Column, String, Float, Integer, Text, DateTime,
    ForeignKey, JSON
)

# UUID: PostgreSQL-native UUID column type (stored as 16 bytes, not a string).
# as_uuid=True means SQLAlchemy automatically converts between Python uuid.UUID and the DB format.
# CONNECTED TO: PostgreSQL database — this type only works with PostgreSQL.
from sqlalchemy.dialects.postgresql import UUID

# relationship: defines how two models are connected at the Python object level.
# Example: company.tiers gives you all PricingTier objects belonging to that company.
# This is NOT a database column — it's a Python-level convenience.
from sqlalchemy.orm import relationship

# Base: the parent class all models inherit from.
# database.py creates it via declarative_base().
# CONNECTED TO: database.py — Base.metadata.create_all() in main.py creates all tables.
from database import Base


# ══════════════════════════════════════════════════════════════
# TABLE 1: users
# PURPOSE: Stores registered users (email + hashed password + ID).
# Each user can own multiple companies.
# ══════════════════════════════════════════════════════════════
class User(Base):
    # __tablename__: the actual PostgreSQL table name. Must be unique across all models.
    __tablename__ = "users"

    # id: UUID primary key. Every row has a unique ID.
    # primary_key=True → this is the unique identifier for each row.
    # default=uuid.uuid4 → SQLAlchemy calls uuid.uuid4() automatically when inserting a new row.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # email: the user's login email. String means VARCHAR in PostgreSQL.
    # unique=True → two users cannot have the same email (database enforces this).
    # nullable=False → email cannot be NULL (empty) — every user must have one.
    # index=True → creates a DB index for fast lookups by email (used in login queries).
    email = Column(String, unique=True, nullable=False, index=True)

    # password_hash: bcrypt hash of the user's password.
    # WHY store hash not plain password? If the DB is stolen, passwords are safe.
    # nullable=False → every user must have a password.
    # CONNECTED TO: auth.py hash_password() creates this, verify_password() checks it.
    password_hash = Column(String, nullable=False)

    # created_at: timestamp when the user registered.
    # default=datetime.utcnow → SQLAlchemy calls datetime.utcnow() on row insert.
    created_at = Column(DateTime, default=datetime.utcnow)

    # companies: Python-level relationship. user.companies → list of Company objects.
    # back_populates="owner" → the Company model has an "owner" attribute pointing back here.
    # cascade="all, delete-orphan" → if a user is deleted, ALL their companies are deleted too
    #   (and then all tiers, features, competitors, sessions cascade-delete further).
    # CONNECTED TO: Company model below, companies.py router uses user_id for ownership checks.
    companies = relationship("Company", back_populates="owner", cascade="all, delete-orphan")

    # password_reset_tokens: user.password_reset_tokens → list of PasswordResetToken objects.
    # cascade="all, delete-orphan" → if user is deleted, their reset tokens are deleted too.
    # CONNECTED TO: PasswordResetToken model below, auth.py /forgot-password endpoint.
    password_reset_tokens = relationship(
        "PasswordResetToken", cascade="all, delete-orphan"
    )


# ══════════════════════════════════════════════════════════════
# TABLE 2: companies
# PURPOSE: Stores companies that users create to analyze (e.g., "CloudHR Pro").
# Each company belongs to one user and has tiers, competitors, and analysis sessions.
# ══════════════════════════════════════════════════════════════
class Company(Base):
    __tablename__ = "companies"

    # id: UUID primary key for this company.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # user_id: foreign key linking this company to its owner (the users table).
    # ForeignKey("users.id") → references the id column in the users table.
    # ondelete="CASCADE" → if the user is deleted in PostgreSQL, this row auto-deletes too.
    # nullable=False → every company must belong to a user.
    # CONNECTED TO: User model above, auth.py get_current_user verifies ownership via this.
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    # name: the company name entered by the user (e.g., "CloudHR Pro").
    name = Column(String, nullable=False)

    # industry: category of the business (e.g., "saas_b2b", "saas_b2c").
    # CONNECTED TO: module1_revenue.py uses industry to look up price elasticity rates.
    industry = Column(String, nullable=False)

    # description: optional longer description of the company.
    # nullable=True → can be left blank.
    description = Column(Text, nullable=True)

    # created_at: timestamp when the company was created.
    created_at = Column(DateTime, default=datetime.utcnow)

    # owner: reverse relationship — company.owner → the User object who owns this company.
    # back_populates="companies" → mirrors user.companies relationship above.
    # CONNECTED TO: User model, used in analysis.py to send notification emails.
    owner = relationship("User", back_populates="companies")

    # tiers: company.tiers → list of PricingTier objects for this company.
    # cascade="all, delete-orphan" → deleting a company deletes all its tiers too.
    # CONNECTED TO: PricingTier model, companies.py CRUD endpoints, analysis engine.
    tiers = relationship("PricingTier", back_populates="company", cascade="all, delete-orphan")

    # competitors: company.competitors → list of Competitor objects.
    # CONNECTED TO: Competitor model, competitors.py router.
    competitors = relationship("Competitor", back_populates="company", cascade="all, delete-orphan")

    # analysis_sessions: company.analysis_sessions → list of AnalysisSession objects.
    # CONNECTED TO: AnalysisSession model, analysis.py router.
    analysis_sessions = relationship("AnalysisSession", back_populates="company", cascade="all, delete-orphan")


# ══════════════════════════════════════════════════════════════
# TABLE 3: pricing_tiers
# PURPOSE: Each row is one pricing plan for a company (e.g., Basic $49/month).
# A company has 1–N tiers. Each tier has user_count and price for MRR calculations.
# ══════════════════════════════════════════════════════════════
class PricingTier(Base):
    __tablename__ = "pricing_tiers"

    # id: UUID primary key for this tier.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # company_id: foreign key linking this tier to its parent company.
    # CASCADE means if the company is deleted, all its tiers are deleted too.
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)

    # name: the tier name (e.g., "Basic", "Growth", "Enterprise").
    name = Column(String, nullable=False)

    # price: the monthly (or annual) price of this tier in USD.
    # Float means decimal numbers like 49.0 or 299.99 are supported.
    # CONNECTED TO: module1_revenue.py multiplies price × user_count to get MRR.
    price = Column(Float, nullable=False)

    # billing_cycle: "monthly" or "annual" — determines how revenue is counted.
    # default="monthly" → if not specified, assume monthly billing.
    # CONNECTED TO: schemas.py TierCreate validates this must be "monthly" or "annual".
    billing_cycle = Column(String, nullable=False, default="monthly")

    # user_count: how many users/customers are on this tier right now.
    # CONNECTED TO: module1_revenue.py uses this: current_mrr = price × user_count.
    user_count = Column(Integer, nullable=False, default=0)

    # churn_rate: optional fraction of users who leave per month (0.0 to 1.0).
    # nullable=True → not required (many users won't know their exact churn rate).
    # Example: 0.05 means 5% of users leave each month.
    churn_rate = Column(Float, nullable=True)

    # created_at: when this tier was added.
    created_at = Column(DateTime, default=datetime.utcnow)

    # company: tier.company → the Company object this tier belongs to.
    # CONNECTED TO: Company model above.
    company = relationship("Company", back_populates="tiers")

    # features: tier.features → list of Feature objects for this tier.
    # cascade="all, delete-orphan" → deleting a tier deletes all its features.
    # CONNECTED TO: Feature model, module2_features.py reads features to classify them.
    features = relationship("Feature", back_populates="tier", cascade="all, delete-orphan")


# ══════════════════════════════════════════════════════════════
# TABLE 4: features
# PURPOSE: Each row is one feature included in a pricing tier.
# Example: "API Access" is a feature on the "Growth" tier.
# ══════════════════════════════════════════════════════════════
class Feature(Base):
    __tablename__ = "features"

    # id: UUID primary key.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # tier_id: foreign key linking this feature to its parent tier.
    # CASCADE → deleting the tier deletes all its features.
    tier_id = Column(UUID(as_uuid=True), ForeignKey("pricing_tiers.id", ondelete="CASCADE"), nullable=False)

    # feature_name: the name of this feature (e.g., "Dashboard", "SSO", "API Access").
    # CONNECTED TO: module2_features.py sends these names to the Groq AI to classify them.
    feature_name = Column(String, nullable=False)

    # description: optional longer description of what the feature does.
    # nullable=True → can be empty.
    description = Column(Text, nullable=True)

    # tier: feature.tier → the PricingTier object this feature belongs to.
    # CONNECTED TO: PricingTier model above.
    tier = relationship("PricingTier", back_populates="features")


# ══════════════════════════════════════════════════════════════
# TABLE 5: competitors
# PURPOSE: Stores competitor pricing pages that the user wants to benchmark against.
# Each competitor has a URL and scraped text from their pricing page.
# ══════════════════════════════════════════════════════════════
class Competitor(Base):
    __tablename__ = "competitors"

    # id: UUID primary key.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # company_id: links this competitor to the company being analyzed.
    # CASCADE → deleting the company deletes all competitors too.
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)

    # name: optional human-readable name of the competitor (e.g., "Salesforce").
    # nullable=True → user may just enter a URL without naming the competitor.
    name = Column(String, nullable=True)

    # url: the competitor's pricing page URL (e.g., "https://salesforce.com/pricing").
    # nullable=False → URL is always required.
    # CONNECTED TO: scraper.py calls scrape_competitor(url) on this value.
    url = Column(String, nullable=False)

    # raw_scraped_text: the full raw text scraped from the competitor's pricing page.
    # nullable=True → starts as NULL until the scraper runs.
    # Text → can be very long (up to 12,000 characters based on scraper config).
    # CONNECTED TO: scraper.py writes here, module3_benchmark.py reads this for Groq prompt.
    raw_scraped_text = Column(Text, nullable=True)

    # clean_scraped_text: a cleaned/filtered version of raw_scraped_text.
    # The scraper removes noise (navbars, footers, legal text) and keeps only pricing-relevant lines.
    # CONNECTED TO: scraper.py's _clean_pricing_content() generates this.
    clean_scraped_text = Column(Text, nullable=True)

    # scrape_status: tracks what happened during scraping. Possible values:
    # "pending"     → scrape hasn't run yet
    # "success_layer1" → scraped successfully with requests (fast)
    # "success_layer2" → scraped successfully with Playwright (slower, JS-rendered)
    # "failed"      → both layers failed
    # "manual_required" → could not scrape, user should paste text manually
    # CONNECTED TO: competitors.py router updates this, analysis.py re-tries failed ones.
    scrape_status = Column(String, nullable=False, default="pending")

    # created_at: when this competitor was added.
    created_at = Column(DateTime, default=datetime.utcnow)

    # company: competitor.company → the Company this competitor belongs to.
    company = relationship("Company", back_populates="competitors")


# ══════════════════════════════════════════════════════════════
# TABLE 6: analysis_sessions
# PURPOSE: Tracks each time the user runs an analysis on a company.
# Stores the progress (0–100%) and status ("running", "completed", "failed").
# ══════════════════════════════════════════════════════════════
class AnalysisSession(Base):
    __tablename__ = "analysis_sessions"

    # id: UUID primary key — also used as the session_id in the SSE progress stream.
    # CONNECTED TO: analysis.py creates this UUID when /start/{company_id} is called.
    #               frontend polls /progress/{session_id} using this ID.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # company_id: links this session to the company being analyzed.
    # CASCADE → deleting the company deletes all its analysis sessions.
    company_id = Column(UUID(as_uuid=True), ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)

    # status: current state of the analysis. Possible values:
    # "pending"   → just created, not started yet
    # "running"   → engine modules are executing
    # "m1_m2_complete" → modules 1 and 2 finished (50% done)
    # "m3_complete"    → module 3 finished (75% done)
    # "m4_complete"    → module 4 finished (90% done)
    # "completed" → all 4 modules ran successfully
    # "partial"   → some modules had errors but analysis still produced output
    # "failed"    → catastrophic failure (e.g., DB error before any module ran)
    # CONNECTED TO: analysis.py run_full_analysis() updates this, SSE stream sends it to frontend.
    status = Column(String, nullable=False, default="pending")

    # progress: integer from 0 to 100 indicating how far along the analysis is.
    # Updated at key milestones: 0 (start), 50 (M1+M2 done), 75 (M3 done), 90 (M4 done), 100 (complete).
    # CONNECTED TO: analysis.py push() function updates this, SSE stream sends it to frontend.
    progress = Column(Integer, nullable=False, default=0)

    # started_at: when the analysis was kicked off.
    started_at = Column(DateTime, default=datetime.utcnow)

    # completed_at: when the analysis finished (or failed). Starts as NULL.
    # nullable=True → stays NULL while the analysis is still running.
    completed_at = Column(DateTime, nullable=True)

    # error_message: stores the error text if analysis fails catastrophically.
    # nullable=True → only filled when status="failed".
    error_message = Column(Text, nullable=True)

    # company: session.company → the Company object being analyzed.
    # CONNECTED TO: Company model, analysis.py reads company data via _load_company_data().
    company = relationship("Company", back_populates="analysis_sessions")

    # report: session.report → the Report object for this session (if completed).
    # uselist=False → one session has exactly one report (one-to-one relationship).
    # CONNECTED TO: Report model below.
    report = relationship("Report", back_populates="session", uselist=False, cascade="all, delete-orphan")


# ══════════════════════════════════════════════════════════════
# TABLE 7: reports
# PURPOSE: Stores the final analysis output — the full JSON report and PDF path.
# Each report belongs to exactly one analysis session.
# ══════════════════════════════════════════════════════════════
class Report(Base):
    __tablename__ = "reports"

    # id: UUID primary key for this report.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # session_id: foreign key linking this report to its analysis session.
    # unique=True → each session can have only one report (enforced by DB).
    # CASCADE → deleting the session deletes the report.
    # CONNECTED TO: AnalysisSession model, analysis.py /report/{session_id} endpoint.
    session_id = Column(UUID(as_uuid=True), ForeignKey("analysis_sessions.id", ondelete="CASCADE"), unique=True, nullable=False)

    # json_report: the full analysis output as a JSON dictionary.
    # Contains all 4 module outputs: module1_revenue, module2_features,
    # module3_benchmark, module4_recommendations.
    # JSON column type → PostgreSQL stores it as JSONB (efficient binary JSON).
    # CONNECTED TO: analysis.py assembles this dict, frontend reads it to render charts/cards.
    json_report = Column(JSON, nullable=False)

    # pdf_path: absolute file path to the generated PDF file on disk.
    # Example: "C:\Users\...\backend\generated_pdfs\<session_id>.pdf"
    # nullable=True → NULL if PDF generation failed (e.g., WeasyPrint not installed).
    # CONNECTED TO: pdf_generator.py writes the PDF file, analysis.py /pdf endpoint serves it.
    pdf_path = Column(String, nullable=True)

    # created_at: when the report was saved.
    created_at = Column(DateTime, default=datetime.utcnow)

    # session: report.session → the AnalysisSession this report belongs to.
    # CONNECTED TO: AnalysisSession model.
    session = relationship("AnalysisSession", back_populates="report")


# ══════════════════════════════════════════════════════════════
# TABLE 8: password_reset_tokens
# PURPOSE: Stores temporary tokens used for "Forgot Password" flow.
# When a user requests a password reset, a random token is generated,
# saved here, and emailed to them. The token expires in 1 hour.
# ══════════════════════════════════════════════════════════════
class PasswordResetToken(Base):
    __tablename__ = "password_reset_tokens"

    # id: UUID primary key.
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # user_id: which user this reset token belongs to.
    # CASCADE → if user is deleted, their reset tokens are deleted too.
    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
    )

    # token: the random 32-byte URL-safe string sent in the reset email link.
    # Generated by: secrets.token_urlsafe(32) in auth.py.
    # unique=True → no two tokens can be the same (prevents collisions).
    # index=True → fast lookup when user clicks the reset link.
    # CONNECTED TO: auth.py /forgot-password creates this, /reset-password validates it.
    token = Column(String, unique=True, nullable=False, index=True)

    # expires_at: when this token becomes invalid (set to now + 1 hour).
    # The /reset-password endpoint checks: if reset.expires_at < datetime.utcnow() → reject.
    expires_at = Column(DateTime, nullable=False)

    # used: "no" by default, changed to "yes" after the token is used successfully.
    # String instead of Boolean because: avoids database-level boolean compatibility issues.
    # WHY track used? Prevents a token from being used twice (replay attack protection).
    # CONNECTED TO: auth.py /reset-password checks used == "yes" and rejects if so.
    used = Column(String, nullable=False, default="no")
