"""
module1_revenue.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Module 1 — Revenue Impact Analysis (pure Python math, NO AI required).

What it does:
  Calculates the company's current Monthly Recurring Revenue (MRR) from all
  pricing tiers. Then simulates 3 price-increase scenarios (+10%, +20%, +30%)
  and estimates how much revenue would increase AND how many users would leave
  (using industry-specific price elasticity data).

WHY no AI? This module only does math — addition, multiplication, percentages.
AI is not needed, and avoiding it makes M1 faster and more reliable.

CONNECTED TO:
  - analysis.py  → calls run_module1(company_data) wrapped in asyncio.to_thread()
                   (it's synchronous, so thread wrapping is needed)
  - analysis.py  → M1 output is passed as input to M3 (competitor benchmark)
                   and M4 (pricing recommendations) for context
  - models.py    → PricingTier.price and PricingTier.user_count are the inputs
  - schemas.py   → TierCreate validates price (ge=0) and user_count (ge=0)
  - json_report  → M1 output stored in Report.json_report["module1_revenue"]
"""

# Any: a typing hint that means "this value can be any Python type".
# Used in type hints to indicate a dict value can be float, dict, str, etc.
# CONNECTED TO: Python's typing module (standard library).
from typing import Any

# ─────────────────────────────────────────────────────────────────────────────
# ELASTICITY TABLE
# ─────────────────────────────────────────────────────────────────────────────
# Price elasticity of demand: how many users leave when prices increase.
# Each key is an industry type, each value is a dict of scenario → fraction lost.
# Example: "saas_b2b" at "+20%" → 0.08 means 8% of users leave if price goes up 20%.
#
# WHY different elasticity per industry?
#   - saas_b2b (Business-to-Business): companies buy based on ROI, less price-sensitive.
#     They have contracts, approved budgets, and higher switching costs.
#     → Low elasticity: only 3%/8%/18% leave at 10%/20%/30% increases.
#   - saas_b2c (Business-to-Consumer): individuals pay from their own pocket.
#     They can cancel anytime and are more price-sensitive.
#     → High elasticity: 8%/18%/32% leave.
#   - default: used for any industry that doesn't match saas_b2b or saas_b2c.
#     Middle ground between b2b and b2c.
#
# CONNECTED TO: _resolve_elasticity() selects the right row based on company.industry.
#               module1 uses these fractions in the scenario loop below.
ELASTICITY: dict[str, dict[str, float]] = {
    "saas_b2b": {"+10%": 0.03, "+20%": 0.08, "+30%": 0.18},  # low sensitivity (B2B)
    "saas_b2c": {"+10%": 0.08, "+20%": 0.18, "+30%": 0.32},  # high sensitivity (B2C)
    "default":  {"+10%": 0.05, "+20%": 0.12, "+30%": 0.25},  # middle ground (other)
}

# SCENARIOS: the three price increase options we always analyze.
# This list controls the loop — adding "+40%" here would add a fourth scenario everywhere.
SCENARIOS = ["+10%", "+20%", "+30%"]

# MULTIPLIERS: the factor to multiply the current price by for each scenario.
# "+10%" → multiply by 1.10 (price goes up 10%)
# "+20%" → multiply by 1.20 (price goes up 20%)
# "+30%" → multiply by 1.30 (price goes up 30%)
# CONNECTED TO: the scenario loop in run_module1() uses: new_price = price * MULTIPLIERS[scenario]
MULTIPLIERS = {"+10%": 1.10, "+20%": 1.20, "+30%": 1.30}


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: _resolve_elasticity
# ─────────────────────────────────────────────────────────────────────────────
# Looks up the correct elasticity dict for a given industry string.
# The leading underscore (_) means this is a "private" helper — only used inside this file.
# Parameters:
#   industry → the industry string from company_data["industry"] (e.g., "saas_b2b")
# Returns: a dict like {"+10%": 0.03, "+20%": 0.08, "+30%": 0.18}
# CONNECTED TO: run_module1() calls this to get the right elasticity values.
def _resolve_elasticity(industry: str) -> dict[str, float]:
    # Normalize the industry string: lowercase and replace spaces with underscores.
    # "SaaS B2B" → "saas_b2b" so it matches the ELASTICITY dict keys.
    industry_lower = industry.lower().replace(" ", "_")

    # Loop through known elasticity keys ("saas_b2b", "saas_b2c", "default").
    # Check if the key appears ANYWHERE in the industry string (substring match).
    # WHY substring? A user might type "enterprise saas_b2b software" and we still want to match.
    for key in ELASTICITY:
        if key in industry_lower:   # e.g., "saas_b2b" in "saas_b2b_enterprise" → True
            return ELASTICITY[key]  # return the matching elasticity dict

    # If no match found, return the "default" elasticity.
    return ELASTICITY["default"]


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FUNCTION: run_module1
# ─────────────────────────────────────────────────────────────────────────────
# This is a SYNCHRONOUS function (no "async def") — it only does math, no I/O.
# WHY synchronous? Math doesn't need async — it doesn't wait for network or DB.
# analysis.py wraps it: asyncio.to_thread(run_module1, company_data)
# so it runs in a thread without blocking the FastAPI event loop.
#
# Parameters:
#   company_data → dict with keys: name, industry, tiers (list of tier dicts)
#                  Built by _load_company_data() in analysis.py from the DB.
# Returns: a dict with current MRR, all scenarios, per-tier breakdown,
#          the recommended scenario, and a human-readable reasoning string.
# CONNECTED TO: analysis.py calls this and stores result as m1_result,
#               which feeds into m3_result and m4_result as context.
def run_module1(company_data: dict) -> dict:
    """
    Synchronous revenue simulation.
    Expected company_data keys: name, industry, tiers (list of tier dicts).
    """
    # Extract industry and tiers from the company_data dict.
    # .get("industry", "") → safely returns "" if the key is missing (won't crash).
    industry = company_data.get("industry", "")

    # tiers → list of tier dicts. Each tier dict has: name, price, user_count, features, etc.
    # Example: [{"name": "Basic", "price": 49.0, "user_count": 200, ...}]
    # CONNECTED TO: _load_company_data() in analysis.py builds this from DB models.
    tiers = company_data.get("tiers", [])

    # Get the correct elasticity dict for this company's industry.
    # CONNECTED TO: _resolve_elasticity() above.
    elasticity = _resolve_elasticity(industry)

    # ── Calculate current MRR ─────────────────────────────────────────────
    # MRR = Monthly Recurring Revenue = sum of (price × user_count) for each tier.
    # sum(...): adds up all tier MRRs.
    # t["price"] * t["user_count"]: e.g., $49 × 200 users = $9,800/month for Basic tier.
    # for t in tiers: iterates each tier dict.
    # CONNECTED TO: M3 and M4 receive current_mrr as context for benchmarking.
    current_mrr = sum(t["price"] * t["user_count"] for t in tiers)

    # ── Initialize accumulators for aggregated (company-level) scenarios ──
    # We'll sum up per-tier projected MRRs into these totals.
    # dict comprehension: creates {"+10%": 0.0, "+20%": 0.0, "+30%": 0.0}
    scenario_totals: dict[str, float] = {s: 0.0 for s in SCENARIOS}

    # Track how many users we'll lose per scenario (as raw counts, not percentages).
    scenario_user_loss: dict[str, float] = {s: 0.0 for s in SCENARIOS}

    # total_users: sum of all users across all tiers.
    # max(..., 1): prevents division by zero if all tiers have user_count=0.
    total_users = max(sum(t["user_count"] for t in tiers), 1)

    # per_tier_results: list where we'll store each tier's individual scenario results.
    # Final result: [{"tier_name": "Basic", "current_mrr": 9800, "scenarios": {...}}, ...]
    per_tier_results = []

    # ── Per-tier scenario loop ─────────────────────────────────────────────
    # Process each tier individually to get per-tier MRR projections.
    for tier in tiers:
        # Extract the current price and user count for this tier.
        price = tier["price"]       # e.g., 49.0 (dollars per month)
        users = tier["user_count"]  # e.g., 200 (current users on this tier)

        # Current MRR for just this tier (before any price change).
        tier_current_mrr = price * users  # e.g., 49.0 × 200 = 9800.0

        # dict to store this tier's scenario projections.
        tier_scenarios: dict[str, Any] = {}

        # Loop through each scenario: "+10%", "+20%", "+30%"
        for scenario in SCENARIOS:
            # loss_pct: fraction of users lost at this scenario (from elasticity table).
            # Example: "+20%" with saas_b2b → 0.08 (8% of users leave)
            loss_pct = elasticity[scenario]

            # remaining_users: users left after the price-sensitive ones leave.
            # Example: 200 users × (1 - 0.08) = 200 × 0.92 = 184 users remaining.
            remaining_users = users * (1 - loss_pct)

            # new_price: the price after applying the percentage increase.
            # MULTIPLIERS["+20%"] = 1.20, so: 49.0 × 1.20 = $58.80/month.
            new_price = price * MULTIPLIERS[scenario]

            # new_mrr: revenue from this tier after the price change and user loss.
            # 184 remaining_users × $58.80 new_price = $10,819.20 projected MRR.
            new_mrr = remaining_users * new_price

            # Store the results for this scenario in the tier dict.
            tier_scenarios[scenario] = {
                # Round to 2 decimal places (cents).
                "projected_mrr": round(new_mrr, 2),

                # Convert fraction to percentage: 0.08 × 100 = 8.0 (display as 8%).
                "user_loss_pct": round(loss_pct * 100, 2),

                # net_change_pct: how much MRR changed compared to current.
                # ((new_mrr - current_mrr) / current_mrr) × 100
                # max(tier_current_mrr, 0.01): prevents division by zero if tier has no users.
                # Example: (10819.2 - 9800) / 9800 × 100 = +10.4%
                "net_change_pct": round(
                    ((new_mrr - tier_current_mrr) / max(tier_current_mrr, 0.01)) * 100, 2
                ),
            }

            # Add this tier's projected MRR to the running company-level total.
            # This will be summed across all tiers to get the aggregate scenario result.
            scenario_totals[scenario] += new_mrr

            # Track total users lost (raw count) to compute weighted percentage later.
            # users * loss_pct = actual number of users lost (e.g., 200 × 0.08 = 16 users).
            scenario_user_loss[scenario] += users * loss_pct

        # Add this tier's complete results to the list.
        per_tier_results.append(
            {
                "tier_name": tier["name"],              # e.g., "Basic"
                "current_mrr": round(tier_current_mrr, 2),  # e.g., 9800.0
                "scenarios": tier_scenarios,             # the 3 scenario dicts above
            }
        )

    # ── Build aggregated company-level scenarios ──────────────────────────
    # Sum up all per-tier projections into one company-level view.
    aggregate_scenarios: dict[str, Any] = {}
    for scenario in SCENARIOS:
        # Total projected MRR across ALL tiers for this scenario.
        proj_mrr = round(scenario_totals[scenario], 2)

        # Net MRR change vs current: ((projected - current) / current) × 100
        net_change = round(
            ((proj_mrr - current_mrr) / max(current_mrr, 0.01)) * 100, 2
        )

        # Weighted overall user loss percentage across all tiers.
        # scenario_user_loss[scenario] = total users lost across all tiers (raw count).
        # Dividing by total_users gives the fraction, × 100 gives the percentage.
        # Example: 24 users lost / 300 total users × 100 = 8.0%
        overall_loss_pct = round((scenario_user_loss[scenario] / total_users) * 100, 2)

        aggregate_scenarios[scenario] = {
            "projected_mrr": proj_mrr,          # total company MRR after change
            "user_loss_pct": overall_loss_pct,  # % of all users who leave
            "net_change_pct": net_change,        # % change in revenue vs current
        }

    # ── Pick the best scenario ────────────────────────────────────────────
    # Find the scenario with the highest projected MRR.
    # max(SCENARIOS, key=...): iterates all scenarios and picks the one where
    # aggregate_scenarios[s]["projected_mrr"] is highest.
    # This is the "recommended" price increase to the user.
    best_scenario = max(SCENARIOS, key=lambda s: aggregate_scenarios[s]["projected_mrr"])

    # Get the full data dict for the best scenario.
    best_data = aggregate_scenarios[best_scenario]

    # Build a human-readable explanation of why this scenario was chosen.
    # Uses f-string formatting with specific number formatting:
    # {:,.2f} → comma-separated thousands with 2 decimal places (e.g., "34,492.27")
    # {:+.1f} → show sign (+ or -) with 1 decimal (e.g., "+10.4%")
    # {:.1f}  → 1 decimal, no sign (e.g., "8.0%")
    # CONNECTED TO: M4 (recommendations) receives this in m1_output as context.
    reasoning = (
        f"{best_scenario} increase yields highest projected MRR of "
        f"${best_data['projected_mrr']:,.2f} "
        f"({best_data['net_change_pct']:+.1f}% change) "
        f"with an estimated {best_data['user_loss_pct']:.1f}% user loss — "
        f"best balance of revenue gain and acceptable churn."
    )

    # ── Return the complete M1 result dict ────────────────────────────────
    # This dict becomes full_report["module1_revenue"] in analysis.py.
    # It's stored in the Report DB row and sent to the frontend.
    return {
        "current_mrr": round(current_mrr, 2),          # total MRR right now (e.g., 31243.0)
        "scenarios": aggregate_scenarios,               # {"+10%": {...}, "+20%": {...}, "+30%": {...}}
        "per_tier": per_tier_results,                   # breakdown per tier
        "recommended_increase": best_scenario,          # e.g., "+20%"
        "reasoning": reasoning,                         # human-readable explanation string
    }
