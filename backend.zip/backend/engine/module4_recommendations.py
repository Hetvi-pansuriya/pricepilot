"""
module4_recommendations.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Module 4 — Final Strategy Recommendations (Groq AI call #3).

What it does:
  Takes ALL previous module outputs (M1 revenue data, M2 feature audit,
  M3 competitor benchmark) and synthesizes them into exactly 3 complete
  pricing strategy proposals for the user to choose from.

The 3 strategies always generated:
  1. CONSERVATIVE: small changes, low risk, 8-15% MRR gain
  2. AGGRESSIVE: major restructure, high risk, 20-40% MRR gain
  3. STRATEGIC: market repositioning, enterprise focus, long-term play

WHY 3 strategies? Different users have different risk tolerances.
  A bootstrapped startup might want "conservative", while a VC-funded
  company going for growth might choose "aggressive".

CONNECTED TO:
  - analysis.py    → run_module4(company_data, m1_output, m2_output, m3_output, groq_client)
                     called after M3 completes (at 90% progress mark)
  - groq_utils.py  → call_groq_with_retry() makes the actual AI API call
  - module1, 2, 3  → their outputs are passed as context (m1_output, m2_output, m3_output)
  - json_report    → stored in Report.json_report["module4_recommendations"]
  - frontend       → displays strategies as selectable cards with charts
"""

# json: converts Python dicts to JSON strings for embedding in the AI prompt.
# The m1/m2/m3 outputs are Python dicts — we JSON-serialize them for the prompt.
import json

# call_groq_with_retry: the shared Groq helper with retry + rate-limit handling.
# CONNECTED TO: engine/groq_utils.py
from engine.groq_utils import call_groq_with_retry


# ── Default fallback response ──────────────────────────────────────────────────
# _FALLBACK: returned when Groq fails or API key is missing.
# "error" key is added at the call site (below) before returning.
# The frontend checks for "error" key to show an appropriate message.
# CONNECTED TO: analysis.py checks "error" in m4_result to set any_module_failed = True.
_FALLBACK = {
    "executive_summary": "Analysis unavailable due to AI service error.",  # shown in report header
    "strategies": [],  # empty list — no strategies could be generated
}


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FUNCTION: run_module4
# ─────────────────────────────────────────────────────────────────────────────
# async def → must be awaited. Async because call_groq_with_retry() is async.
#
# Parameters:
#   company_data → basic company info (name, industry) for prompt context.
#   m1_output    → dict from module1 (current MRR, scenarios, per_tier data).
#   m2_output    → dict from module2 (feature_audit list, summary).
#   m3_output    → dict from module3 (competitors_parsed, benchmark data).
#   groq_client  → the Groq AI client object (or None if key missing).
# Returns: dict with "executive_summary" string and "strategies" list.
# CONNECTED TO: analysis.py stores this as m4_result, included in full_report.
async def run_module4(
    company_data: dict,
    m1_output: dict,
    m2_output: dict,
    m3_output: dict,
    groq_client,
) -> dict:
    """
    Calls Groq to produce 3 alternative pricing strategies.
    Falls back to a partial result if Groq fails.
    """
    # Extract company name and industry for the prompt.
    # These give the AI context about what kind of company it's advising.
    name = company_data.get("name", "Unknown")      # e.g., "CloudHR Pro"
    industry = company_data.get("industry", "Unknown")  # e.g., "saas_b2b"

    # ── Build the AI prompt ───────────────────────────────────────────────
    # This is the longest and most complex prompt in the system.
    # It sends ALL previous analysis outputs as context, then asks for 3 full strategies.
    # json.dumps() converts the Python dict to a JSON string for embedding in the f-string.
    # WHY include all 3 module outputs? M4 synthesizes everything — it needs:
    #   - M1: current MRR, which price increase is recommended, churn risk
    #   - M2: which features are misplaced (gatekeepers/blockers to fix)
    #   - M3: how we compare to competitors, what features we're missing
    prompt = f"""You are a senior SaaS pricing strategist. You have complete analysis data for a company. Generate exactly 3 alternative pricing strategies.

COMPANY: {name}, INDUSTRY: {industry}

MODULE 1 — REVENUE MODEL:
{json.dumps(m1_output)}

MODULE 2 — FEATURE AUDIT:
{json.dumps(m2_output)}

MODULE 3 — COMPETITOR BENCHMARK:
{json.dumps(m3_output)}

Generate EXACTLY 3 pricing strategies:
1. CONSERVATIVE — low risk, minor changes, 8–15% MRR gain, minimal disruption
2. AGGRESSIVE — high risk, significant restructure, 20–40% MRR gain, possible churn
3. STRATEGIC — market repositioning, enterprise focus, rename tiers, long-term play

For EACH strategy provide a complete new tier structure with specific prices and features.

Respond ONLY with this exact JSON:
{{
  "executive_summary": "2-3 sentence summary of the biggest pricing problem and the single most impactful fix",
  "strategies": [
    {{
      "type": "conservative|aggressive|strategic",
      "name": "short name for this strategy",
      "predicted_mrr_change_pct": 12,
      "confidence_score": 0.85,
      "risk_level": "low|medium|high",
      "reasoning": "2-3 sentences explaining why this strategy works",
      "new_tier_structure": [
        {{
          "name": "new tier name",
          "price": 99,
          "key_changes": ["moved API access to this tier", "added SSO"],
          "target_customer": "who this tier is for"
        }}
      ],
      "implementation_steps": ["step 1", "step 2", "step 3"]
    }}
  ]
}}

Return ONLY the JSON. No markdown. No backticks."""

    # ── Guard: return stub if no Groq client ──────────────────────────────
    # ** operator: unpacks the _FALLBACK dict into this new dict.
    # Equivalent to: {"executive_summary": "...", "strategies": [], "error": "...", "module": "M4"}
    if groq_client is None:
        return {
            **_FALLBACK,                                    # spread _FALLBACK keys
            "error": "GROQ_API_KEY not configured",        # add error key
            "module": "M4",                                 # identify which module failed
        }

    # ── Make the AI call ──────────────────────────────────────────────────
    # Try block: call Groq and return the parsed dict on success.
    try:
        result = await call_groq_with_retry(groq_client, prompt)
        return result  # parsed JSON dict with executive_summary and strategies list

    except (ValueError, AttributeError) as e:
        # ValueError → all Groq retries exhausted.
        # AttributeError → unexpected response structure.
        # Return fallback with error info — analysis still marks status as "partial".
        return {
            **_FALLBACK,          # spread _FALLBACK keys (executive_summary, strategies)
            "error": str(e),      # actual error message for debugging
            "module": "M4",       # identifies which module failed
        }
