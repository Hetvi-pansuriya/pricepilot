"""
module3_benchmark.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Module 3 — Competitor Benchmarking (Groq AI call #2 in the pipeline).

What it does:
  1. Receives scraped competitor pricing page text (from scraper.py).
  2. Asks the Groq AI to parse the messy scraped text into structured data
     (competitor tier names, prices, and features).
  3. Computes "value scores" (price ÷ feature count) for each tier.
  4. Produces a benchmark analysis: are we overpriced? underpriced? what
     features do competitors have that we don't?

WHY value score? price ÷ feature_count = cost per feature. Lower = better value.
  Basic tier with 4 features at $49 = $12.25/feature (good value).
  Pro tier with 2 features at $99  = $49.50/feature (poor value).

CONNECTED TO:
  - analysis.py   → run_module3(company_data, m1_output, m2_output, competitors, groq_client)
                    called after M1+M2 finish (at 50% progress mark)
  - groq_utils.py → call_groq_with_retry() makes the actual AI API call
  - scraper.py    → provides clean_scraped_text/raw_scraped_text used in the prompt
  - analysis.py   → m3_result fed into M4 as context for strategy recommendations
  - json_report   → stored in Report.json_report["module3_benchmark"]
"""

# json: converts Python dicts/lists to JSON strings for embedding in the AI prompt.
# Used to serialize tiers_summary and our_value_scores into the prompt string.
import json

# copy: provides deep copy functionality.
# Used to safely clone _EMPTY_BENCHMARK (the fallback dict) without mutating the original.
# WHY deepcopy? Shallow copy would share nested dicts — modifying one would affect the other.
import copy

# call_groq_with_retry: the shared Groq helper with retry + rate-limit handling.
# CONNECTED TO: engine/groq_utils.py
from engine.groq_utils import call_groq_with_retry


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: _build_our_value_scores
# ─────────────────────────────────────────────────────────────────────────────
# Computes a simple "value score" for each of our pricing tiers.
# Formula: value_score = tier_price / number_of_features
# Lower value_score = more features per dollar = better value for the customer.
# This is a pure math helper — no AI needed.
#
# Parameters:
#   tiers → list of tier dicts from company_data["tiers"]
#   Each tier has: name, price, features (list of feature dicts)
# Returns: list of dicts like [{"tier_name": "Basic", "value_score": 12.25}, ...]
# CONNECTED TO: run_module3() calls this, and the result is embedded in the AI prompt
#               AND always included in the final output regardless of AI success.
def _build_our_value_scores(tiers: list) -> list:
    """Compute value_score = price / feature_count for each tier (lower = better value)."""
    scores = []  # accumulate results here
    for tier in tiers:
        # Get the number of features. If 0 features, use 1 to avoid division by zero.
        # tier.get("features", []) → safely returns empty list if key missing.
        feature_count = len(tier.get("features", [])) or 1  # "or 1" prevents ZeroDivisionError

        # value_score = price per feature. Example: $49 / 4 features = 12.25
        # round(..., 2) → 2 decimal places for clean display.
        value_score = round(tier["price"] / feature_count, 2)

        # Append this tier's result to the scores list.
        scores.append({"tier_name": tier["name"], "value_score": value_score})
    return scores  # e.g., [{"tier_name": "Basic", "value_score": 12.25}, ...]


# ─────────────────────────────────────────────────────────────────────────────
# FALLBACK CONSTANT: _EMPTY_BENCHMARK
# ─────────────────────────────────────────────────────────────────────────────
# This is the default result returned when there are no competitor URLs,
# or when all competitors failed to scrape (no text available to benchmark against).
# It's a "module-level constant" (prefixed with _ → private to this file).
# Note: our_value_scores is always overwritten with real calculated values.
# WHY constant? Avoids repeated dict construction and provides a consistent shape
# that the frontend always knows how to handle.
# CONNECTED TO: run_module3() returns a deepcopy of this when no competitors exist.
_EMPTY_BENCHMARK = {
    "competitors_parsed": [],       # empty list — no competitors were parsed by AI
    "benchmark": {
        "our_value_scores": [],     # will be overwritten by _build_our_value_scores()
        "positioning": "unknown",   # can't determine positioning without competitor data
        "features_we_lack": [],     # unknown without competitor comparison
        "features_we_uniquely_have": [],  # unknown without competitor comparison
        "price_vs_market": "No competitor data available for benchmarking.",  # shown in report
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FUNCTION: run_module3
# ─────────────────────────────────────────────────────────────────────────────
# async def → must be awaited. Async because call_groq_with_retry() is async.
#
# Parameters:
#   company_data → dict from _load_company_data() (name, industry, tiers, competitors)
#   m1_output    → dict from module1 — used to show current MRR in the prompt context
#   m2_output    → dict from module2 — not directly used in prompt but available for future
#   competitors  → list of competitor dicts (with url, clean_scraped_text, raw_scraped_text)
#   groq_client  → the Groq client from app.state.groq_client (or None if key missing)
# Returns: dict with competitors_parsed list and benchmark dict.
# CONNECTED TO: analysis.py calls this, stores result as m3_result, feeds it to M4.
async def run_module3(
    company_data: dict,
    m1_output: dict,
    m2_output: dict,
    competitors: list,       # list of dicts from _load_company_data() in analysis.py
    groq_client,             # Groq client or None
) -> dict:
    """
    Calls Groq to parse competitor text and benchmark the target company.
    Falls back to placeholder if no competitor data exists.
    """
    # Extract basic company info for use in the prompt and value score calculation.
    name = company_data.get("name", "Unknown")      # e.g., "CloudHR Pro"
    industry = company_data.get("industry", "Unknown")  # e.g., "saas_b2b"
    tiers = company_data.get("tiers", [])           # list of our pricing tier dicts

    # ── Filter to only competitors with actual scraped content ────────────
    # usable_competitors: competitors that have either clean or raw text to analyze.
    # We check both because: if clean text is empty, we fall back to raw text.
    # .strip(): removes whitespace — a string of only spaces is considered empty.
    # WHY filter? Sending blank competitor data would waste tokens and produce bad AI output.
    # CONNECTED TO: scraper.py provides clean_scraped_text, competitors.py provides raw text.
    usable_competitors = [
        c                                       # keep this competitor
        for c in competitors                    # iterate all competitor dicts
        if (
            c.get("clean_scraped_text")         # prefer clean text
            or c.get("raw_scraped_text")         # fallback to raw text
            or ""                               # fallback to empty string if both missing
        ).strip()                              # strip and check if non-empty
    ]

    # ── Always compute our value scores (even if no competitors) ─────────
    # These scores are always shown in the report regardless of AI availability.
    our_value_scores = _build_our_value_scores(tiers)

    # ── Build the empty fallback with our value scores filled in ──────────
    # copy.deepcopy: creates a completely independent copy of _EMPTY_BENCHMARK.
    # WHY deepcopy? If we just did empty = _EMPTY_BENCHMARK, then
    #   empty["benchmark"]["our_value_scores"] = ... would mutate the module-level constant,
    #   breaking all subsequent calls to run_module3().
    empty = copy.deepcopy(_EMPTY_BENCHMARK)
    empty["benchmark"]["our_value_scores"] = our_value_scores  # fill in our scores

    # ── Early return if no competitor data ────────────────────────────────
    # If no competitor has scraped text, we can't do benchmarking.
    # Return the empty benchmark (with our value scores) immediately.
    if not usable_competitors:
        return empty  # M3 result with our scores but no competitor comparison

    # ── Build the competitor text block for the prompt ────────────────────
    # Concatenate all competitor texts into one block, labeled by competitor name/URL.
    # This block is embedded verbatim in the AI prompt.
    competitor_block = ""  # accumulate here
    for comp in usable_competitors:
        # Prefer clean_scraped_text (noise-filtered) over raw text.
        # clean_scraped_text is produced by scraper.py's _clean_pricing_content().
        text_to_use = (
            comp.get("clean_scraped_text")   # first choice: cleaned text
            or comp.get("raw_scraped_text")   # fallback: raw scraped HTML text
            or ""                            # final fallback: empty string
        )
        if not text_to_use.strip():
            continue  # skip competitors with no text even after fallback

        # Add a labeled section for this competitor.
        # comp.get("name", comp["url"]) → use name if available, else URL as label.
        # [:5000] → truncate to 5000 chars to avoid exceeding Groq's token limit.
        # Total max input: 5 competitors × 5000 chars = 25,000 chars → ~6,000 tokens.
        competitor_block += (
            f"--- COMPETITOR: {comp.get('name', comp['url'])} ---\n"
            f"{text_to_use[:5000]}\n\n"  # 5000 char limit per competitor
        )

    # ── Build a simplified summary of OUR tiers for the prompt ────────────
    # We only send what's needed: tier name, price, and feature names.
    # Omit IDs, churn_rate, billing_cycle — not relevant for competitor comparison.
    tiers_summary = [
        {
            "name": t["name"],           # e.g., "Basic"
            "price": t["price"],          # e.g., 49.0
            # List comprehension: extract just feature names from the feature dicts.
            "features": [f["feature_name"] for f in t.get("features", [])],
        }
        for t in tiers
    ]

    # ── Build the AI prompt ───────────────────────────────────────────────
    # This is a detailed prompt that gives the AI:
    # 1. Its role (SaaS pricing benchmarking expert)
    # 2. Our company data (tiers + MRR from M1)
    # 3. Raw competitor scraped text
    # 4. Exact JSON schema to respond with
    # WHY embed our_value_scores in the schema? So the AI knows to preserve them
    # even when generating the benchmark section.
    prompt = f"""You are a SaaS pricing benchmarking expert. Given a company's pricing data and raw competitor pricing page text, extract structured competitor data and produce a benchmark analysis.

TARGET COMPANY: {name}
INDUSTRY: {industry}
CURRENT MRR: {m1_output.get("current_mrr", "unknown")}
TIERS: {json.dumps(tiers_summary)}

COMPETITOR RAW TEXT:
{competitor_block}

TASK:
1. Parse each competitor's raw text to extract: tier names, prices, and key features (best effort — text may be messy)
2. Compute a value score for each tier = price / feature_count (lower = better value)
3. Compare the target company's tiers against each competitor

Respond ONLY with this exact JSON schema:
{{
  "competitors_parsed": [
    {{
      "name": "string",
      "tiers": [
        {{"name": "string", "price": null, "features": ["string"], "value_score": null}}
      ]
    }}
  ],
  "benchmark": {{
    "our_value_scores": {json.dumps(our_value_scores)},
    "positioning": "overpriced|underpriced|well_positioned",
    "features_we_lack": ["feature competitors have that we don't"],
    "features_we_uniquely_have": ["our differentiators"],
    "price_vs_market": "one sentence — are we above/below/at market rate"
  }}
}}

Return ONLY the JSON. No markdown. No backticks."""

    # ── Guard: return stub if no Groq client ──────────────────────────────
    # groq_client is None when GROQ_API_KEY is not set in .env.
    # Return a deep copy of empty so our_value_scores is preserved.
    if groq_client is None:
        fallback = copy.deepcopy(empty)        # copy the empty benchmark with our scores
        fallback["error"] = "GROQ_API_KEY not configured"  # error key for frontend
        fallback["module"] = "M3"              # identifies which module failed
        return fallback

    # ── Make the AI call ──────────────────────────────────────────────────
    try:
        result = await call_groq_with_retry(groq_client, prompt)

        # ── Ensure our_value_scores is always present in the result ───────
        # The AI should include our_value_scores (we put it in the schema),
        # but if it omits the key or returns an empty list, we fill it in.
        # WHY? our_value_scores is computed from real data and must always be shown.
        if "benchmark" in result:
            if not result["benchmark"].get("our_value_scores"):
                # AI didn't include it — inject our calculated scores.
                result["benchmark"]["our_value_scores"] = our_value_scores

        return result  # the parsed AI response dict

    except (ValueError, AttributeError) as e:
        # ValueError → all Groq retries failed.
        # AttributeError → unexpected response structure.
        # Return a fallback with our value scores preserved.
        fallback = copy.deepcopy(empty)  # deep copy of empty benchmark
        fallback["error"] = str(e)       # actual error for debugging
        fallback["module"] = "M3"        # identifies which module failed
        return fallback
