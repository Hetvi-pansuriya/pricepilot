﻿"""
groq_utils.py
â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
PURPOSE: Shared helper that wraps the Groq AI API with retry logic,
         rate-limit handling, and JSON parsing.

HOW IT WORKS:
  1. Takes a prompt string and a Groq client object.
  2. Calls the Groq chat completion API (llama model) in a thread (non-blocking).
  3. Parses the JSON response from the model.
  4. If something goes wrong (rate limit, bad JSON), retries with corrections.

CONNECTED TO:
  - module2_features.py   â†’ calls call_groq_with_retry() for feature classification
  - module3_benchmark.py  â†’ calls call_groq_with_retry() for competitor benchmarking
  - module4_recommendations.py â†’ calls call_groq_with_retry() for strategy generation
  - analysis.py           â†’ passes the groq_client from app.state to these modules
  - main.py               â†’ creates the Groq client on startup (stored in app.state)
"""

# asyncio: Python's async concurrency library.
# Used here for:
#   - asyncio.to_thread(): run blocking code (Groq SDK) in a background thread
#     so the FastAPI event loop isn't blocked during AI API calls.
#   - asyncio.sleep(): wait N seconds before retrying on rate limit.
import asyncio

# json: Python standard library for parsing JSON strings.
# Used to parse the AI model's text response into a Python dict.
import json

# re: Python's regular expression library.
# Used to strip markdown code fences (```json ... ```) from the model response
# in case the model wraps its JSON in backticks despite being told not to.
import re

# os: read environment variables.
# Used to read GROQ_MODEL env var (allows changing model without editing code).
import os

# The Groq model ID to use for all AI calls.
# This is the global setting â€” change this ONE line to switch the model everywhere.
# llama-3.3-70b-versatile:
#   - 70 billion parameters â†’ very capable for complex reasoning tasks
#   - "versatile" variant â†’ good all-rounder for structured JSON output
#   - Replaced the deprecated llama3-70b-8192 (decommissioned by Groq)
# CONNECTED TO: call_groq_with_retry() uses this as the model= parameter.
GROQ_MODEL = "qwen/qwen3.8-27b"


# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# MAIN FUNCTION: call_groq_with_retry
# â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
# This is an async function (defined with "async def") â€” it must be awaited.
# Parameters:
#   client      â†’ the Groq client object from app.state.groq_client (created in main.py)
#   prompt      â†’ the full prompt string to send to the AI (built in each module)
#   max_retries â†’ how many times to try before giving up (default 3)
# Returns: a Python dict parsed from the AI's JSON response.
# Raises: ValueError if all retries are exhausted.
# CONNECTED TO: called by module2, module3, module4 with their respective prompts.
async def call_groq_with_retry(client, prompt: str, max_retries: int = 3) -> dict:
    """
    Call the Groq chat completion API with retry logic.

    - On JSON parse error: re-prompts asking for clean JSON (once)
    - On rate-limit / 429 error: waits 30 seconds then retries
    - On other errors: breaks immediately
    Raises ValueError if all retries exhausted.
    """
    # last_error: stores the most recent error message for the final ValueError.
    # WHY? So we can tell the user what went wrong after all retries fail.
    last_error = None

    # current_prompt: the prompt we send to the model. May be modified on retry
    # (we append instructions to fix JSON errors on subsequent attempts).
    current_prompt = prompt

    # Loop up to max_retries times. attempt goes 0, 1, 2 (for max_retries=3).
    for attempt in range(max_retries):
        try:
            # â”€â”€ Make the API call â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            # The Groq Python SDK is SYNCHRONOUS (it uses httpx internally).
            # Running synchronous blocking code inside an async FastAPI endpoint
            # would freeze the server â€” no other requests could be processed.
            # Solution: asyncio.to_thread() runs the blocking Groq call in a
            # separate thread from the OS threadpool, leaving the event loop free.
            # CONNECTED TO: client = app.state.groq_client from main.py
            response = await asyncio.to_thread(
                client.chat.completions.create,  # the synchronous Groq API method

                # model: which AI model to use. Reads from env var first (allows override
                # without code changes), falls back to llama-3.3-70b-versatile.
                model="qwen/qwen3.8-27b",

                # messages: the conversation history sent to the model.
                # Groq uses the OpenAI chat format: a list of message dicts.
                messages=[
                    {
                        # "system" role: sets the AI's persona/behavior for this entire call.
                        # This is the "instruction layer" â€” tells the AI what kind of expert it is
                        # and what format to respond in. Very important for JSON reliability.
                        "role": "system",
                        "content": (
                            "You are a SaaS pricing expert. "             # establishes expertise
                            "Always respond with ONLY a valid JSON object. "  # format constraint
                            "No markdown fences, no backticks, no explanation outside the JSON."  # no decorators
                        ),
                    },
                    {
                        # "user" role: the actual question/task we're asking.
                        # current_prompt is the full prompt built by module2/3/4.
                        # It may be modified on retry to add JSON correction instructions.
                        "role": "user",
                        "content": current_prompt,
                    },
                ],

                # temperature: controls how "creative" vs "deterministic" the AI is.
                # 0.0 = fully deterministic (same prompt â†’ same output every time)
                # 1.0 = very creative/random
                # 0.3 = slightly random but mostly consistent â€” good for structured JSON.
                # WHY 0.3 not 0.0? A tiny bit of randomness helps avoid degenerate outputs.
                temperature=0.3,

                # max_tokens: maximum number of tokens (roughly words) in the response.
                # 4096 is large enough for a complete multi-strategy JSON response.
                # If the response is truncated (hits this limit), JSON will be incomplete.
                # CONNECTED TO: module4 produces the longest output (3 full strategies).
                max_tokens=4096,

                # response_format: tells Groq to ENFORCE valid JSON output at the model level.
                # This is different from just asking the model in the prompt â€” Groq actually
                # filters the output to guarantee it starts/ends with valid JSON braces.
                # {"type": "json_object"} is the Groq/OpenAI spec for JSON mode.
                # WHY still parse JSON manually? Defense in depth â€” in case of edge cases.
                response_format={"type": "json_object"},
            )

            # â”€â”€ Parse the response â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            # response.choices â†’ list of completion choices (Groq can return multiple but
            #   we always get index [0] since we didn't request multiple completions).
            # .message â†’ the assistant's message object.
            # .content â†’ the text string of the response.
            # .strip() â†’ removes leading/trailing whitespace.
            text = response.choices[0].message.content.strip()

            # â”€â”€ Strip markdown fences (defensive) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            # Even with response_format=json_object, some models occasionally wrap
            # their JSON in ```json ... ``` markdown backticks.
            # This block detects and removes those fences.
            if text.startswith("```"):
                # re.sub: replaces regex matches with a replacement string.
                # r"^```[a-z]*\n?" matches: ``` followed by optional language name and newline.
                # Example: "```json\n" â†’ removed, leaving just the JSON.
                text = re.sub(r"^```[a-z]*\n?", "", text)

                # r"\n?```$" matches: optional newline followed by ``` at the end.
                # Example: "\n```" â†’ removed.
                text = re.sub(r"\n?```$", "", text)

                text = text.strip()  # remove any remaining whitespace

            # json.loads: parse the text string into a Python dict.
            # This is the successful exit path â€” if it works, we return the dict.
            # CONNECTED TO: module2/3/4 receive this dict as their return value.
            return json.loads(text)

        # â”€â”€ Handle JSON parse errors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        except json.JSONDecodeError as e:
            # The model returned something that isn't valid JSON (despite our instructions).
            # Save the error description for potential final error message.
            last_error = f"JSON parse error: {e}"

            # Only add correction instructions if we have retries left.
            # attempt < max_retries - 1 means we're not on the last attempt.
            if attempt < max_retries - 1:
                # Append strong correction instructions to the original prompt.
                # The next iteration sends this modified prompt.
                # CRITICAL in all caps: increases the model's attention to this instruction.
                current_prompt = (
                    current_prompt
                    + "\n\nCRITICAL: Your previous response was not valid JSON. "
                    "Return ONLY a valid JSON object. No markdown, no backticks, no text outside the JSON braces."
                )
            # continue â†’ skip to the next loop iteration (next attempt).
            continue

        # â”€â”€ Handle all other errors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        except Exception as e:
            error_str = str(e)  # convert the exception to a string for inspection

            # â”€â”€ Rate limit detection â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            # Groq's rate limit error contains "rate_limit" or "429" in the error string.
            # "429" = HTTP Too Many Requests status code.
            # "rate limit" (with space) catches natural language error messages.
            if "rate_limit" in error_str.lower() or "429" in error_str or "rate limit" in error_str.lower():
                wait_seconds = 30  # how long to wait before retrying (Groq resets quickly)
                print(f"Groq rate limit hit on attempt {attempt + 1}, waiting {wait_seconds}s...")
                # await asyncio.sleep: non-blocking wait â€” other requests can run while waiting.
                await asyncio.sleep(wait_seconds)
                # continue â†’ try again after the wait.
                continue

            # â”€â”€ Non-rate-limit error â†’ stop immediately â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            # Examples: invalid API key, network error, model not found.
            # No point retrying these â€” they won't fix themselves.
            last_error = error_str  # save for the final ValueError message
            break  # exit the for loop immediately

    # â”€â”€ All retries exhausted or fatal error â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    # If we get here, all attempts failed.
    # Raise ValueError with a descriptive message.
    # CONNECTED TO: module2/3/4 catch this ValueError and return a fallback dict
    #               with "error" key so the analysis can still partially complete.
    raise ValueError(f"Groq API failed after {max_retries} retries: {last_error}")
