# ─── main.py ─────────────────────────────────────────────────────────────────
# PURPOSE: The entry point of the entire FastAPI backend application.
#          This file creates the FastAPI app, configures startup/shutdown,
#          sets up CORS, registers all routers, and provides the health check.
# CONNECTED TO: database.py (DB engine), models.py (table creation),
#               all 4 routers (auth, companies, analysis, competitors),
#               groq_utils.py (Groq AI client stored on app.state).
# HOW TO RUN: uvicorn main:app --reload --port 8000
# ─────────────────────────────────────────────────────────────────────────────

# os: used to read environment variables (GROQ_API_KEY, FRONTEND_URL, etc.)
import os

# Path: Object-Oriented file path handling. Better than os.path for cross-platform paths.
# Used here to find the .env file relative to this script's location.
from pathlib import Path

# asynccontextmanager: decorator that turns an async function with yield into a
# context manager — used to define the "lifespan" (startup + shutdown) of the FastAPI app.
from contextlib import asynccontextmanager

# load_dotenv: reads .env file and injects its key=value pairs into os.environ.
# This must be called before any os.getenv() calls.
from dotenv import load_dotenv

# text: lets you write raw SQL strings for SQLAlchemy async engine.
# Used here to add a missing column during auto-migration on startup.
from sqlalchemy import text

# Explicitly compute the absolute path to the .env file sitting next to main.py.
# __file__ = path to this main.py file.
# .resolve() → converts to absolute path (handles symlinks).
# .parent → goes up to the directory containing main.py (i.e., the backend/ folder).
# / ".env" → appends the .env filename.
# WHY explicit path? uvicorn's reloader spawns a child process that might run from a
# different working directory, causing a plain load_dotenv() to miss the file.
env_path = Path(__file__).resolve().parent / ".env"

# Load the .env file from the explicit path computed above.
# override=True → if a variable already exists in os.environ, overwrite it with .env value.
# This ensures the .env file always takes precedence over system environment variables.
load_dotenv(dotenv_path=env_path, override=True)

# Diagnostic prints to help debug .env loading issues.
# If GROQ_API_KEY shows as "NO" in startup logs, check this path.
print(f"DIAGNOSTIC: Looking for .env file at: {env_path}")  # shows the path being searched
print(f"DIAGNOSTIC: Does file exist? {env_path.exists()}")   # shows True/False if file found

# FastAPI: the web framework that handles HTTP requests, routing, and validation.
from fastapi import FastAPI

# CORSMiddleware: handles Cross-Origin Resource Sharing — allows the React frontend
# (running on localhost:5173) to make API calls to this backend (running on localhost:8000).
# Without CORS, browsers block requests between different origins (ports/domains).
from fastapi.middleware.cors import CORSMiddleware

# engine: the database connection pool (from database.py).
# Base: the parent class of all SQLAlchemy models (from database.py).
# Both are needed to auto-create tables on startup.
# CONNECTED TO: database.py
from database import engine, Base

# Import all 4 router modules — each handles a different API section.
# auth       → /auth/signup, /auth/login, /auth/forgot-password, etc.
# companies  → /companies CRUD (create, read, update, delete companies/tiers/features)
# analysis   → /analysis/start, /analysis/progress, /analysis/report, /analysis/history
# competitors→ /companies/{id}/competitors CRUD + scrape trigger
# CONNECTED TO: routers/auth.py, routers/companies.py, routers/analysis.py, routers/competitors.py
from routers import auth, companies, analysis, competitors

# Groq: the AI API client class. Used to make AI calls to the Groq cloud API.
# After init, this client is stored in app.state.groq_client and passed to engine modules.
# CONNECTED TO: engine/groq_utils.py calls client.chat.completions.create()
#               analysis.py reads app.state.groq_client and passes to run_module2/3/4
from groq import Groq


# ─── Lifespan ─────────────────────────────────────────────────────────────────
# The lifespan function defines what happens when the server STARTS UP and SHUTS DOWN.
# FastAPI calls the code BEFORE `yield` on startup, and code AFTER `yield` on shutdown.
# @asynccontextmanager makes it work as an async context manager with `yield`.
# CONNECTED TO: passed to FastAPI(lifespan=lifespan) below.

@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Step 1: Create / verify database tables ──────────────────────────────
    # This runs Base.metadata.create_all which looks at all models in models.py
    # and creates any tables that don't already exist in the PostgreSQL database.
    # WHY try/except? If the DB is unreachable at startup, we print a warning
    # instead of crashing — the server still starts, just without a working DB.
    try:
        # engine.begin(): opens a new database connection as a transaction.
        async with engine.begin() as conn:
            # run_sync: runs a synchronous SQLAlchemy method (create_all) inside an async context.
            # Base.metadata.create_all: looks at all model classes and creates missing tables.
            # This is a DEV convenience — in production, use Alembic migrations instead.
            await conn.run_sync(Base.metadata.create_all)
        print("SUCCESS: Database tables created/verified.")  # appears in the server console
    except Exception as e:
        # Print the error but don't crash — server runs without DB (useful for debugging config)
        print(f"WARNING: Could not connect to database on startup: {e}")

    # ── Step 2: Auto-migration — add missing column to competitors table ──────
    # The `clean_scraped_text` column was added after initial deployment.
    # This block safely adds it if it doesn't exist yet (IF NOT EXISTS prevents errors).
    # WHY here and not Alembic? Quick hotfix for existing deployments.
    try:
        async with engine.begin() as conn:
            # Raw SQL: ALTER TABLE competitors ADD COLUMN IF NOT EXISTS clean_scraped_text TEXT
            # "IF NOT EXISTS" → won't error if the column already exists.
            # text() wraps the raw SQL string for SQLAlchemy to execute safely.
            await conn.execute(text(
                "ALTER TABLE competitors ADD COLUMN IF NOT EXISTS clean_scraped_text TEXT"
            ))
        print("SUCCESS: Migration check complete.")
    except Exception as e:
        print(f"WARNING: Migration check failed: {e}")  # non-fatal, continue startup
        
    # ── Step 3: Create PDF output directory ──────────────────────────────────
    # All generated PDF files are saved in: backend/generated_pdfs/<session_id>.pdf
    # os.path.dirname(__file__) → the directory where main.py lives (backend/).
    # os.path.join → safely joins path parts with the right separator (/ or \).
    # os.makedirs(..., exist_ok=True) → creates the folder if it doesn't exist,
    #   does nothing if it already exists (exist_ok=True prevents "already exists" errors).
    # CONNECTED TO: pdf_generator.py saves PDFs here, analysis.py serves them for download.
    pdf_dir = os.path.join(os.path.dirname(__file__), "generated_pdfs")
    os.makedirs(pdf_dir, exist_ok=True)  # creates the folder silently if missing

    # ── Step 4: Initialize Groq AI client ────────────────────────────────────
    # Read the Groq API key from the .env file (loaded above).
    # GROQ_API_KEY is a string starting with "gsk_..." — required to call Groq's AI API.
    # CONNECTED TO: .env file must have GROQ_API_KEY=gsk_...
    api_key = os.getenv("GROQ_API_KEY", "")  # "" = default if the key is missing

    # Diagnostic: print whether the key was found (shows first 8 chars for safety).
    print(f"DEBUG: GROQ_API_KEY loaded = {'YES (' + api_key[:8] + '...)' if api_key else 'NO — check .env file'}")

    if api_key:
        # Key is present — create the Groq client object and store it on app.state.
        # app.state is a special FastAPI attribute for storing shared app-level objects.
        # WHY app.state? The Groq client is a singleton — we create it once here and
        # every request reads it via request.app.state.groq_client.
        # CONNECTED TO: analysis.py start_analysis() reads: getattr(request.app.state, "groq_client", None)
        app.state.groq_client = Groq(api_key=api_key)
        print("SUCCESS: Groq client initialized.")
    else:
        # No API key — set to None so engine modules can detect this and return stub results.
        app.state.groq_client = None
        print("WARNING: GROQ_API_KEY not set.")  # AI analysis will return empty stubs

    # ── Step 5: Check email notification config (optional feature) ──────────
    # SENDGRID_API_KEY and FROM_EMAIL are optional — email notifications are disabled by default.
    # If both are set in .env, analysis completion emails are sent to users.
    # CONNECTED TO: email_service.py (if it exists), analysis.py sends emails after analysis.
    if os.getenv("SENDGRID_API_KEY", "") and os.getenv("FROM_EMAIL", ""):
        print("SUCCESS: Email notifications enabled (SendGrid).")
    else:
        print("INFO: SendGrid credentials not set; email notifications disabled.")

    # ── yield ─────────────────────────────────────────────────────────────────
    # Everything ABOVE this line runs at startup.
    # Everything BELOW this line runs at shutdown.
    # FastAPI "yields" control to the app here — the server runs until stopped.
    yield
    # Shutdown: nothing to clean up currently (DB connections managed by SQLAlchemy pool).


# ─── App ──────────────────────────────────────────────────────────────────────
# Create the FastAPI application instance — this is the actual WSGI/ASGI app.
# title, description, version → shown in the auto-generated Swagger UI at /docs.
# lifespan → the startup/shutdown function defined above.
# CONNECTED TO: uvicorn runs this: "uvicorn main:app --reload"
app = FastAPI(
    title="SaaS Pricing Analyzer API",                               # shown in /docs
    description="Automated SaaS Pricing Sensitivity Analyzer — backend API",  # shown in /docs
    version="1.0.0",                                                  # API version string
    lifespan=lifespan,                                                # startup/shutdown logic
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
# CORS = Cross-Origin Resource Sharing.
# Problem: The React frontend runs on localhost:5173 but the backend runs on localhost:8000.
# Browsers block requests between different ports (different "origins") by default.
# Solution: Tell the browser which origins are allowed to make requests to this API.

# Read the deployed frontend URL from .env (for production Vercel deployment).
# Falls back to the Vercel URL if not set.
frontend_url = os.getenv("FRONTEND_URL", "https://pricepilot-six.vercel.app")

# Add CORSMiddleware to the app — it intercepts every request and adds CORS headers.
app.add_middleware(
    CORSMiddleware,                    # the middleware class to use
    allow_origins=[                    # list of domains allowed to call this API
        "http://localhost:5173",       # React dev server (Vite default port)
        "http://localhost:3000",       # React dev server (Create React App default port)
        frontend_url,                  # deployed Vercel production frontend URL
    ],
    allow_credentials=True,           # allow cookies and Authorization headers to be sent
    allow_methods=["*"],              # allow all HTTP methods (GET, POST, DELETE, etc.)
    allow_headers=["*"],              # allow all headers (including Authorization for JWT)
)

# ─── Routers ──────────────────────────────────────────────────────────────────
# Register each router with its URL prefix and OpenAPI tag.
# prefix → all routes in that router get this prepended to their path.
# tags   → used to group endpoints in the /docs Swagger UI.

# Auth endpoints: /auth/signup, /auth/login, /auth/forgot-password, /auth/reset-password
# CONNECTED TO: routers/auth.py
app.include_router(auth.router, prefix="/auth", tags=["auth"])

# Company endpoints: /companies, /companies/{id}, /companies/{id}/tiers, etc.
# CONNECTED TO: routers/companies.py
app.include_router(companies.router, prefix="/companies", tags=["companies"])

# Competitor endpoints: /companies/{id}/competitors, /companies/{id}/competitors/{comp_id}
# WHY same prefix as companies? Competitors are nested under companies in the URL structure.
# CONNECTED TO: routers/competitors.py
app.include_router(competitors.router, prefix="/companies", tags=["competitors"])

# Analysis endpoints: /analysis/start/{company_id}, /analysis/progress/{session_id}, etc.
# CONNECTED TO: routers/analysis.py
app.include_router(analysis.router, prefix="/analysis", tags=["analysis"])


# ─── Health Check Endpoints ────────────────────────────────────────────────────

# GET /health → simple health check endpoint.
# Used by monitoring tools (Render, Railway, UptimeRobot) to verify the server is running.
# include_in_schema=True (default) → shows up in /docs.
# Returns JSON: {"status": "ok", "version": "1.0.0"}
@app.get("/health", tags=["health"])
def health():
    return {"status": "ok", "version": "1.0.0"}

# GET / and HEAD / → root endpoint.
# include_in_schema=False → hidden from /docs (it's just a sanity check).
# methods=["GET", "HEAD"] → HEAD is used by some health check tools that don't need a body.
# WHY HEAD? Some load balancers send HEAD requests to / to check if the server is alive.
@app.api_route("/", methods=["GET", "HEAD"], include_in_schema=False)
def root():
    return {
        "message": "SaaS Pricing Analyzer API is running!"  # confirms server is alive
    }
