"""
alembic/env.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Alembic migration environment configuration.

Alembic is the database migration tool for SQLAlchemy. It tracks changes to
your database schema over time — like Git but for database tables.

HOW TO USE:
  Generate a migration:  alembic revision --autogenerate -m "add column X"
  Apply migrations:      alembic upgrade head
  Rollback last:         alembic downgrade -1

WHY we need this:
  When you change models.py (add/remove columns), the database doesn't update
  automatically. Alembic compares your models to the DB and generates SQL
  ALTER TABLE scripts to bring the DB up to date safely.

CONNECTED TO:
  - database.py  → imports Base (which has all table metadata)
  - models.py    → imported to register all ORM models on Base.metadata
  - alembic.ini  → provides the database URL configuration
  - .env         → DATABASE_URL overrides alembic.ini at runtime
─────────────────────────────────────────────────────────────────────────────
"""

# asyncio: needed because our database driver (asyncpg) is async-only.
# Alembic itself is synchronous, so we use asyncio.run() to bridge the gap.
import asyncio

# os: reads environment variables (DATABASE_URL from .env).
import os

# sys: manipulates Python's module search path.
# We insert the backend/ directory so Alembic can import our custom modules.
import sys

# fileConfig: sets up Python logging from the alembic.ini [loggers] configuration.
# This makes Alembic print readable log messages during migration runs.
from logging.config import fileConfig

# pool: SQLAlchemy connection pool classes.
# NullPool: a pool that doesn't keep connections open between uses.
# WHY NullPool for Alembic? Migrations run once and exit — no need for persistent connections.
from sqlalchemy import pool

# Connection: type hint for the database connection object passed to do_run_migrations.
from sqlalchemy.engine import Connection

# async_engine_from_config: creates an async SQLAlchemy engine from alembic.ini settings.
# CONNECTED TO: uses sqlalchemy.url from alembic.ini (overridden by DATABASE_URL env var).
from sqlalchemy.ext.asyncio import async_engine_from_config

# context: the Alembic context object — provides access to config, connection, and migration API.
# context.run_migrations() → executes pending migrations.
# context.configure() → sets up the migration context with target schema.
from alembic import context

# ── Add backend/ directory to Python path ────────────────────────────────────
# __file__ = path to this env.py file (inside alembic/).
# os.path.dirname(__file__) = the alembic/ directory.
# ".." = go up one level to backend/.
# sys.path.insert(0, ...) → adds backend/ as the FIRST place Python looks for modules.
# WHY position 0? It takes priority over installed packages — prevents import conflicts.
# CONNECTED TO: allows "from database import Base" and "import models" to work below.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# Import Base so Alembic knows about our table definitions.
# Base.metadata contains all the table schemas from models.py.
# noqa: F401 → tells the linter not to warn about "imported but unused" (it IS used via metadata).
# CONNECTED TO: database.py creates Base via declarative_base()
from database import Base  # noqa: F401

# Import models module to ensure ALL model classes are registered on Base.metadata.
# SQLAlchemy ORM models only register themselves when their class is imported.
# Without this line, Base.metadata would be empty → Alembic can't detect any tables.
# noqa: F401 → suppress "unused import" lint warning.
# CONNECTED TO: models.py defines User, Company, PricingTier, Feature, Competitor, etc.
import models  # noqa: F401 — registers all ORM classes on Base.metadata

# ─── Alembic Config ──────────────────────────────────────────────────────────
# context.config → the parsed alembic.ini configuration.
# Provides access to settings like sqlalchemy.url.
config = context.config

# Override the database URL from environment variable if set.
# WHY? alembic.ini contains a hardcoded URL which may be wrong in different environments.
# Setting DATABASE_URL in .env allows Alembic to use the correct connection string
# without editing alembic.ini for each deployment.
# CONNECTED TO: .env file, same DATABASE_URL used by database.py.
db_url = os.getenv("DATABASE_URL", "")  # read from environment
if db_url:
    # Inject the DATABASE_URL into Alembic's config at runtime.
    # This overrides whatever is in alembic.ini [alembic] sqlalchemy.url.
    config.set_main_option("sqlalchemy.url", db_url)

# Set up logging from alembic.ini if a config file is present.
# config.config_file_name → path to alembic.ini (set by Alembic automatically).
# fileConfig(path) → reads [loggers], [handlers], [formatters] sections and configures logging.
# WHY check is not None? Running tests may not have an alembic.ini available.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)  # apply logging config from alembic.ini

# target_metadata: tells Alembic what the "desired" schema looks like.
# Alembic compares target_metadata to the live database schema to find differences.
# Base.metadata → contains all table/column/index definitions from models.py.
# CONNECTED TO: used by both run_migrations_offline() and do_run_migrations().
target_metadata = Base.metadata


# ─── Offline migrations ───────────────────────────────────────────────────────
# "Offline mode" generates SQL scripts WITHOUT connecting to a real database.
# Useful for: generating migration files to review, or for DBs with restricted access.
# Run with: alembic upgrade head --sql > migration.sql

def run_migrations_offline() -> None:
    """Run migrations without a live DB connection (generates SQL script)."""
    # Get the database URL from the config (set above from env var or alembic.ini).
    url = config.get_main_option("sqlalchemy.url")

    # Configure Alembic for offline mode.
    context.configure(
        url=url,                           # target database connection string
        target_metadata=target_metadata,   # our SQLAlchemy models schema
        literal_binds=True,               # embed values directly in SQL (no %s placeholders)
        dialect_opts={"paramstyle": "named"},  # use :name style parameters for readability
    )

    # Execute all pending migrations within a transaction.
    with context.begin_transaction():
        context.run_migrations()  # generates/executes SQL for pending migrations


# ─── Online migrations ────────────────────────────────────────────────────────
# "Online mode" runs migrations against a live, connected database.
# This is the normal mode used in development and production.

def do_run_migrations(connection: Connection) -> None:
    # Configure Alembic with the live connection and our models metadata.
    context.configure(
        connection=connection,           # live database connection
        target_metadata=target_metadata  # our SQLAlchemy models (desired schema)
    )
    # Run all pending migrations within a transaction.
    # If any migration fails, the transaction rolls back (safe atomicity).
    with context.begin_transaction():
        context.run_migrations()  # applies ALTER TABLE, CREATE TABLE, etc.


async def run_async_migrations() -> None:
    """Run migrations against a live async DB connection."""
    # Create an async SQLAlchemy engine from alembic.ini settings.
    # config.get_section(config.config_ini_section, {}) → reads the [alembic] section dict.
    # prefix="sqlalchemy." → reads all keys starting with "sqlalchemy." from that section.
    # poolclass=pool.NullPool → don't keep connections open (Alembic is one-shot).
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),  # alembic.ini [alembic] settings
        prefix="sqlalchemy.",   # key prefix for engine settings (sqlalchemy.url, etc.)
        poolclass=pool.NullPool,  # no connection pool — connect once, migrate, disconnect
    )

    # Open a database connection and run migrations synchronously inside it.
    # connection.run_sync(do_run_migrations) → bridges async connection to sync Alembic API.
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)  # run the sync migration function

    # Dispose the engine — release all resources cleanly after migration.
    await connectable.dispose()


def run_migrations_online() -> None:
    # asyncio.run() → starts a new event loop to run the async migration coroutine.
    # WHY asyncio.run() here? Alembic's entry point is synchronous, but our DB driver
    # (asyncpg) is async-only. This bridges the sync/async boundary.
    asyncio.run(run_async_migrations())


# ─── Entry point ─────────────────────────────────────────────────────────────
# Alembic calls this file directly. Based on its mode, we pick the right function.
# context.is_offline_mode() → True when alembic was called with --sql flag.

if context.is_offline_mode():
    run_migrations_offline()  # generate SQL script without DB connection
else:
    run_migrations_online()   # apply migrations to the live database
