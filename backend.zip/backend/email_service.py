"""
email_service.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Sends optional email notifications via the SendGrid API.

Two email types:
  1. Analysis Complete: sent after a pricing analysis finishes (with PDF attachment).
  2. Password Reset: sent with a reset link after /auth/forgot-password.

WHY optional (non-fatal)?
  Email delivery is a nice-to-have, not core functionality. If SendGrid is
  misconfigured or the network is down, the analysis is still saved to the DB
  and accessible via the frontend. Failing email should NEVER crash the server.

CONNECTED TO:
  - analysis.py → calls send_analysis_complete_email() after run_full_analysis() completes
  - auth.py     → calls send_password_reset_email() in /forgot-password endpoint
  - main.py     → checks if SENDGRID_API_KEY and FROM_EMAIL are set on startup (log only)
  - .env        → SENDGRID_API_KEY, FROM_EMAIL, FRONTEND_URL are read here

SETUP REQUIRED (optional):
  1. Create account at sendgrid.com (free tier: 100 emails/day)
  2. Get API key from Settings → API Keys
  3. Set SENDGRID_API_KEY=SG.xxxxx and FROM_EMAIL=noreply@yourdomain.com in .env
─────────────────────────────────────────────────────────────────────────────
"""

# asyncio: for asyncio.to_thread() — runs the blocking SendGrid SDK calls
# in a background thread so they don't freeze the FastAPI event loop.
import asyncio

# html: Python standard library for HTML escaping.
# html.escape() → converts special characters to HTML entities.
# Example: "Hetvi & Co." → "Hetvi &amp; Co." (safe to embed in HTML email).
# WHY? Prevents XSS if company names contain HTML characters like <, >, &.
import html

# os: reads environment variables (SENDGRID_API_KEY, FROM_EMAIL, FRONTEND_URL).
import os

# Path: object-oriented file path handling.
# Used to check if the PDF file exists before trying to attach it.
from pathlib import Path

# base64: encodes binary PDF data to base64 string for email attachment.
# Email protocols only support text — binary files must be base64-encoded.
# base64 uses 64 printable ASCII characters to represent any binary data.
import base64


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC ASYNC FUNCTION: send_analysis_complete_email
# ─────────────────────────────────────────────────────────────────────────────
# Async wrapper around the synchronous _send() function.
# This is what analysis.py calls after a pricing analysis finishes.
# WHY async? analysis.py is an async context — it can't call blocking _send() directly.
# WHY to_thread()? The SendGrid SDK uses blocking HTTP requests (not async).
#
# Parameters:
#   to_email             → recipient's email address (the user who ran the analysis)
#   company_name         → shown in email subject and body (e.g., "CloudHR Pro")
#   company_id           → used to build the report URL for the CTA button
#   session_id           → used to build the report URL
#   pdf_path             → absolute path to the generated PDF file (may be None)
#   current_mrr          → shown in the email summary stats card (e.g., 31243.0)
#   recommended_increase → shown in the email summary stats card (e.g., "+20%")
# Returns: True if email was sent successfully, False otherwise.
# CONNECTED TO: analysis.py calls this after report is saved to DB.
async def send_analysis_complete_email(
    to_email: str,
    company_name: str,
    company_id: str,
    session_id: str,
    pdf_path: str | None,        # None if PDF generation failed
    current_mrr: float = 0,      # default 0 if M1 didn't run
    recommended_increase: str = "N/A",  # default if M1 didn't provide recommendation
) -> bool:
    try:
        # asyncio.to_thread(): runs the blocking _send() function in a thread pool.
        # This frees the event loop to handle other requests while waiting for SendGrid.
        # All parameters are passed through to _send().
        return await asyncio.to_thread(
            _send,
            to_email,
            company_name,
            company_id,
            session_id,
            pdf_path,
            current_mrr,
            recommended_increase,
        )
    except Exception as error:
        # Catch ALL exceptions — email failure must NEVER crash the analysis flow.
        # Log the error for debugging (visible in server console/logs).
        print(f"[Email] Non-fatal SendGrid failure: {error}")
        return False  # return False to indicate failure (not raised)


# ─────────────────────────────────────────────────────────────────────────────
# PRIVATE SYNC FUNCTION: _send
# ─────────────────────────────────────────────────────────────────────────────
# The actual blocking SendGrid email sending logic.
# Leading underscore (_) means private — only called by send_analysis_complete_email().
# This is synchronous because the sendgrid SDK is synchronous.

def _send(
    to_email: str,
    company_name: str,
    company_id: str,
    session_id: str,
    pdf_path: str | None,
    current_mrr: float = 0,
    recommended_increase: str = "N/A",
) -> bool:
    # ── Read credentials from environment ────────────────────────────────
    # These MUST be set in .env for emails to work.
    # SENDGRID_API_KEY → the API key from your SendGrid account dashboard.
    # FROM_EMAIL → the verified sender email (must be verified in SendGrid).
    # FRONTEND_URL → used to build the "View Full Report" link in the email.
    api_key = os.getenv("SENDGRID_API_KEY", "")
    from_email = os.getenv("FROM_EMAIL", "")
    frontend = os.getenv("FRONTEND_URL", "http://localhost:5173").rstrip("/")  # no trailing slash

    # Guard: if API key missing, skip silently (non-fatal).
    if not api_key:
        print("[Email] SENDGRID_API_KEY not set; notification skipped.")
        return False

    # Guard: if FROM_EMAIL missing, skip (SendGrid requires a verified sender).
    if not from_email:
        print("[Email] FROM_EMAIL not set; notification skipped.")
        return False

    # ── Import sendgrid (optional dependency) ────────────────────────────
    # sendgrid is not installed by default — only when email is enabled.
    # We import inside the function to avoid ImportError crashing the server
    # when sendgrid is not installed (the function just returns False instead).
    try:
        from sendgrid import SendGridAPIClient            # the main SendGrid client
        from sendgrid.helpers.mail import (
            Mail,        # the email message object
            Attachment,  # email attachment wrapper
            FileContent, # base64-encoded file content
            FileName,    # attachment filename
            FileType,    # MIME type of the attachment
            Disposition  # "attachment" or "inline"
        )
    except ImportError:
        print("[Email] sendgrid package not installed. Run: pip install sendgrid")
        return False

    # ── Build the report URL ──────────────────────────────────────────────
    # This is the link shown in the "View Full Report" button in the email.
    # Format: https://pricepilot.vercel.app/company/<uuid>/report/<session_uuid>
    # CONNECTED TO: frontend routing in App.jsx handles this URL pattern.
    report_url = f"{frontend}/company/{company_id}/report/{session_id}"

    # html.escape(): makes company_name safe to embed in HTML.
    # Prevents injection if company name has characters like <, >, &, ", '.
    safe_name = html.escape(company_name)

    # Format MRR for display: "$31,243.00" or "N/A" if 0.
    # ":,.2f" → comma-separated thousands, 2 decimal places.
    mrr_display = f"${current_mrr:,.2f}" if current_mrr else "N/A"

    # ── Build the HTML email template ────────────────────────────────────
    # This is a dark-themed responsive HTML email matching PricePilot's design.
    # Table-based layout: required for email clients (Outlook doesn't support flexbox/grid).
    # Inline CSS: required — most email clients strip <style> tags.
    # {safe_name}: company name (HTML-escaped).
    # {mrr_display}: formatted MRR (e.g., "$31,243.00").
    # {html.escape(recommended_increase)}: safe to embed (e.g., "+20%").
    # {report_url}: the "View Full Report" CTA link.
    html_content = f"""<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;font-family:Arial,sans-serif;background:#101015;">
<table width="100%" cellpadding="0" cellspacing="0">
  <tr><td align="center" style="padding:40px 20px;">
    <table width="520" cellpadding="0" cellspacing="0"
           style="background:#1a1a22;border-radius:12px;border:1px solid rgba(80,99,133,0.22);overflow:hidden;">

      <!-- Header: PricePilot branding with gradient background -->
      <tr>
        <td style="background:linear-gradient(135deg,#506385,#3d5070);padding:28px 32px;">
          <div style="font-size:20px;font-weight:700;color:#fff;">PricePilot</div>
          <div style="font-size:13px;color:rgba(255,255,255,0.75);margin-top:4px;">
            SaaS Pricing Analyzer
          </div>
        </td>
      </tr>

      <!-- Body: analysis summary -->
      <tr>
        <td style="padding:28px 32px;">
          <h2 style="margin:0 0 8px 0;font-size:20px;color:#F1F0E1;">
            Analysis complete ✓
          </h2>
          <p style="margin:0 0 20px 0;font-size:14px;color:rgba(241,240,225,0.55);line-height:1.6;">
            Your pricing analysis for
            <strong style="color:#F1F0E1;">{safe_name}</strong>
            has finished. Here's a quick summary:
          </p>

          <!-- Stats: MRR card + Recommended Increase card side by side -->
          <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;">
            <tr>
              <td width="48%" style="background:#20202c;border:1px solid rgba(80,99,133,0.22);
                          border-radius:8px;padding:14px 16px;">
                <div style="font-size:11px;color:#64748b;text-transform:uppercase;
                            letter-spacing:0.08em;margin-bottom:4px;">Current MRR</div>
                <div style="font-size:22px;font-weight:700;color:#506385;">{mrr_display}</div>
              </td>
              <td width="4%"></td>
              <td width="48%" style="background:#20202c;border:1px solid rgba(80,99,133,0.22);
                          border-radius:8px;padding:14px 16px;">
                <div style="font-size:11px;color:#64748b;text-transform:uppercase;
                            letter-spacing:0.08em;margin-bottom:4px;">Recommended Increase</div>
                <div style="font-size:22px;font-weight:700;color:#22c55e;">
                  {html.escape(recommended_increase)}
                </div>
              </td>
            </tr>
          </table>

          <p style="margin:0 0 24px 0;font-size:13px;color:rgba(241,240,225,0.55);line-height:1.6;">
            The full report includes revenue scenario modeling, feature placement audit,
            competitor benchmarking, and 3 alternative pricing strategies.
            {"<br><br><strong style='color:#F1F0E1;'>PDF report attached.</strong>"
              if pdf_path and Path(pdf_path).is_file() else ""}
          </p>

          <!-- CTA Button: links to the report in the frontend -->
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td style="background:#506385;border-radius:8px;">
                <a href="{report_url}"
                   style="display:inline-block;padding:12px 28px;color:#fff;
                          font-size:14px;font-weight:600;text-decoration:none;">
                  View Full Report →
                </a>
              </td>
            </tr>
          </table>
        </td>
      </tr>

      <!-- Footer -->
      <tr>
        <td style="padding:16px 32px;border-top:1px solid rgba(80,99,133,0.22);">
          <p style="margin:0;font-size:11px;color:#475569;">
            You're receiving this because you ran an analysis on PricePilot.
            This is an automated notification.
          </p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>"""

    # Plain text fallback for email clients that don't support HTML.
    # Most modern clients use HTML, but plain text is required by RFC for accessibility.
    plain_text = (
        f"Your pricing analysis for {company_name} is ready.\n\n"
        f"Current MRR: {mrr_display}\n"
        f"Recommended price increase: {recommended_increase}\n\n"
        f"View full report: {report_url}"
    )

    # ── Build the SendGrid Mail object ────────────────────────────────────
    # Mail is the email message wrapper from sendgrid.helpers.mail.
    # It accepts both plain text and HTML content — email clients choose the best one.
    message = Mail(
        from_email=from_email,    # sender (must be verified in SendGrid)
        to_emails=to_email,       # recipient (the user's email)
        subject=f"PricePilot — Analysis complete for {company_name}",  # email subject line
        plain_text_content=plain_text,   # plain text version (fallback)
        html_content=html_content,       # HTML version (used by most clients)
    )

    # ── Attach PDF if it exists ───────────────────────────────────────────
    # Only attach if: pdf_path is not None AND the file actually exists on disk.
    # Path(pdf_path).is_file() → checks the file exists (not just the path string).
    if pdf_path and Path(pdf_path).is_file():
        # Read the PDF file as raw bytes.
        pdf_data = Path(pdf_path).read_bytes()

        # base64.b64encode(pdf_data) → encode bytes to base64 bytes.
        # .decode() → convert base64 bytes to a UTF-8 string (required by SendGrid).
        encoded = base64.b64encode(pdf_data).decode()

        # Build the Attachment object with all required metadata.
        attachment = Attachment(
            FileContent(encoded),   # base64-encoded PDF content
            # Filename: replace spaces with hyphens for safe filenames.
            # session_id[:8] → first 8 chars of UUID (keeps filename short).
            FileName(f"pricing-report-{company_name.replace(' ', '-')}-{session_id[:8]}.pdf"),
            FileType("application/pdf"),  # MIME type for PDF files
            Disposition("attachment"),    # "attachment" = download, "inline" = show in browser
        )
        message.attachment = attachment  # add the attachment to the email

    # ── Send via SendGrid API ─────────────────────────────────────────────
    # SendGridAPIClient(api_key) → creates the SendGrid client with our API key.
    sg = SendGridAPIClient(api_key)

    # sg.send(message) → makes an HTTP POST to SendGrid's API and returns a response.
    # This is a blocking/synchronous call — run inside asyncio.to_thread() from the caller.
    response = sg.send(message)

    # Log the HTTP status code for debugging.
    # 202 Accepted → SendGrid received the email and will deliver it.
    # 200 OK → also success in some SendGrid SDK versions.
    print(f"[Email] SendGrid response: {response.status_code} → {to_email}")

    # Check if the status code indicates success.
    if response.status_code in (200, 202):
        return True  # email queued successfully
    else:
        # Log the error body for debugging (contains reason for failure).
        print(f"[Email] SendGrid error body: {response.body}")
        return False  # delivery failed


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC ASYNC FUNCTION: send_password_reset_email
# ─────────────────────────────────────────────────────────────────────────────
# Sends a password reset link to the user's email.
# Called by auth.py /forgot-password endpoint after creating a reset token in DB.
# CONNECTED TO: auth.py forgot_password() calls this with the reset link URL.

async def send_password_reset_email(to_email: str, reset_link: str) -> bool:
    try:
        # Run the sync _send_reset() in a thread pool (same pattern as above).
        return await asyncio.to_thread(_send_reset, to_email, reset_link)
    except Exception as error:
        print(f"[Email] Reset email failed: {error}")
        return False  # non-fatal — auth.py continues even if email fails


# ─────────────────────────────────────────────────────────────────────────────
# PRIVATE SYNC FUNCTION: _send_reset
# ─────────────────────────────────────────────────────────────────────────────
# The blocking SendGrid logic for password reset emails.
# Simpler than _send() — no PDF attachment, no MRR data, just a link.

def _send_reset(to_email: str, reset_link: str) -> bool:
    # Read credentials. Both are required.
    api_key = os.getenv("SENDGRID_API_KEY", "")
    from_email = os.getenv("FROM_EMAIL", "")

    # Guard: skip if credentials are missing.
    if not api_key or not from_email:
        print("[Email] Credentials not set; reset email skipped.")
        return False

    # Import SendGrid (optional dependency, same pattern as above).
    try:
        from sendgrid import SendGridAPIClient
        from sendgrid.helpers.mail import Mail
    except ImportError:
        print("[Email] sendgrid package is not installed.")
        return False

    # html.escape(reset_link, quote=True) → escapes the URL for safe HTML embedding.
    # quote=True also escapes " and ' characters (important for href attributes).
    # WHY escape the link? If the reset token contains special characters, this prevents HTML injection.
    safe_link = html.escape(reset_link, quote=True)

    # HTML email for password reset. Simpler design than the analysis email.
    # Contains a clear CTA button with the reset link.
    # "→" → HTML entity for the right arrow character →.
    html_content = f"""
    <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;padding:32px;background:#101015;border-radius:12px;">
      <h2 style="color:#F1F0E1;">Reset your PricePilot password</h2>
      <p style="color:#5a6080;">Click below to set a new password. This link expires in 1 hour.</p>
      <a href="{safe_link}" style="display:inline-block;margin:20px 0;padding:12px 28px;
        background:#506385;color:#101015;border-radius:8px;text-decoration:none;font-weight:600;">
        Reset Password &rarr;
      </a>
      <p style="color:#9399b5;font-size:12px;">If you did not request this, ignore this email.</p>
    </div>"""

    # Build the Mail object with just HTML (no plain text version for this simple email).
    message = Mail(
        from_email=from_email,   # verified sender
        to_emails=to_email,      # the user requesting the reset
        subject="PricePilot — Reset your password",  # email subject
        html_content=html_content,  # the HTML email body
    )

    # Send the email and check if it was accepted (200 or 202).
    response = SendGridAPIClient(api_key).send(message)
    return response.status_code in (200, 202)  # True = success, False = failure
