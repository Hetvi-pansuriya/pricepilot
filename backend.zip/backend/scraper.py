"""
scraper.py
─────────────────────────────────────────────────────────────────────────────
PURPOSE: Five-layer asynchronous competitor pricing page scraper for PricePilot.

When a user adds a competitor URL, this module fetches and cleans the text
from their pricing page so the AI (module3) can benchmark against it.

TWO-LAYER STRATEGY:
  Layer 1: requests (simple HTTP) — fast, works for static sites like Stripe.
  Layer 2: Playwright (headless Chrome) — slower, handles JS-rendered sites.

WHY two layers? Many SaaS pricing pages require JavaScript to render
(React/Next.js apps). requests only gets the raw HTML. Playwright actually
runs the browser, waits for JS to execute, then extracts text.

BUILT-IN OPTIMIZATIONS:
  - In-memory cache (24h TTL) — same URL is only scraped once per server restart.
  - Noise filtering — removes navbars, footers, cookie banners, legal text.
  - Pricing-signal filtering — only keeps text containing pricing keywords.
  - Character limits — caps raw text at 12,000 chars, clean at 8,000.

CONNECTED TO:
  - competitors.py → calls scrape_competitor() in a background task after adding a URL
  - analysis.py   → calls scrape_competitors_concurrent() to retry failed scrapes
  - module3       → receives clean_scraped_text in the company_data["competitors"] list
─────────────────────────────────────────────────────────────────────────────
"""

# os: used to set the Playwright browsers path (where chromium is installed).
import os

# Set the Playwright browser path BEFORE importing playwright.
# On Render.com deployment, Playwright installs chromium here.
# Must be set before any playwright import or it uses the wrong path.
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = "/opt/render/project/src/.playwright"

# asyncio: async concurrency library.
# Used for: asyncio.to_thread() (run sync requests in thread),
#           asyncio.gather() (scrape multiple URLs concurrently).
import asyncio

# hashlib: creates MD5 hashes.
# Used to create a short, fixed-length cache key from a URL string.
# Example: "https://stripe.com/pricing" → "a3f9b2..." (32 hex chars)
import hashlib

# re: regular expressions for text cleaning.
# Used to collapse whitespace, strip markdown, remove noise patterns.
import re

# time: for cache TTL (time-to-live) expiry checks.
# time.time() returns current Unix timestamp as float (seconds since 1970).
import time

# requests: synchronous HTTP library. Simpler and faster than Playwright for static pages.
# WHY synchronous? requests.get() blocks — we run it in asyncio.to_thread() in Layer 1.
import requests

# BeautifulSoup: HTML parser. Converts HTML markup into navigable Python objects.
# "html.parser" is Python's built-in parser (no extra C library needed).
import requests
from bs4 import BeautifulSoup

# ─── In-Memory Cache ──────────────────────────────────────────────────────────
# Scraping is expensive (network calls, browser launching). Cache prevents re-scraping
# the same URL within 24 hours. Stored as a Python dict — lives in server memory.
# WHY in-memory and not Redis? Simplicity. The app is single-process (uvicorn worker).
# LIMITATION: Cache is lost on server restart. Acceptable for development/small deployments.

# _CACHE: the cache store. Key = MD5 hash of URL. Value = result dict + "cached_at" timestamp.
_CACHE: dict[str, dict] = {}

# _CACHE_TTL_SECONDS: 86,400 seconds = 24 hours. After this, cached results expire.
# WHY 24 hours? Competitor prices don't change minute-to-minute. 24h is a good balance.
_CACHE_TTL_SECONDS = 86_400  # 86400 = 60 × 60 × 24 seconds in one day

# _MAX_RAW_CHARS: maximum characters to keep from the raw scraped page text.
# 12,000 chars ≈ 3,000 tokens — enough detail without overwhelming the AI context.
_MAX_RAW_CHARS = 12_000

# _MAX_CLEAN_CHARS: maximum characters in the cleaned pricing text.
# 8,000 chars ≈ 2,000 tokens — clean text is denser so we keep less.
_MAX_CLEAN_CHARS = 8_000

# ─── HTTP Headers ─────────────────────────────────────────────────────────────
# These headers make our requests look like a real browser visiting the page.
# WHY? Many websites block requests with no User-Agent or obvious bot signatures.
# This is the Chrome 124 user agent string for Windows — common and unsuspicious.
_HEADERS = {
    # User-Agent: identifies the browser. "Mozilla/5.0..." is the standard prefix.
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    # Accept: tells the server what content types we can handle.
    # "text/html" → we want HTML pages. "application/xhtml+xml" → also accept XHTML.
    # "q=0.9" → quality preference (lower = lower priority).
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    # Accept-Language: we prefer English content.
    "Accept-Language": "en-US,en;q=0.5",
    # Accept-Encoding: we accept compressed responses (saves bandwidth).
    "Accept-Encoding": "gzip, deflate",
    # Connection: keep the TCP connection alive for potential follow-up requests.
    "Connection": "keep-alive",
    # Upgrade-Insecure-Requests: tell the server we prefer HTTPS over HTTP.
    "Upgrade-Insecure-Requests": "1",
}

# ─── Pricing Keywords ─────────────────────────────────────────────────────────
# Words that indicate pricing content. Used to check if scraped text is useful.
# If the text contains 3+ of these keywords, it's considered pricing content.
# WHY a tuple (not list)? Tuples are slightly faster for "in" checks and are immutable.
_PRICING_KEYWORDS = (
    "plan", "price", "pricing", "per month", "per year", "/mo", "/yr",
    "free", "starter", "pro", "enterprise", "business", "team", "annual",
    "monthly", "billed", "usd", "$", "€", "£", "₹", "upgrade",
    "subscribe", "tier", "features included",
)

# ─── HTML Tags to Remove ──────────────────────────────────────────────────────
# Tags whose entire content we remove during HTML parsing (Layer 1).
# script → JavaScript code (gibberish to AI)
# style  → CSS rules (not useful)
# nav    → navigation menus (not pricing content)
# footer → footer links (legal, privacy, social links)
# noscript → alternative content for no-JS browsers (usually ads)
# iframe → embedded third-party content
# header → site header/logo area
# aside  → sidebars (ads, related articles)
# form   → sign-up forms (noise)
# button → button labels (too short to be meaningful)
# svg    → vector graphics (no text content)
# img, video, audio, canvas, figure, picture → media elements (no text)
_NOISE_TAGS = (
    "script", "style", "nav", "footer", "noscript", "iframe", "header",
    "aside", "form", "button", "svg", "img", "video", "audio", "canvas",
    "figure", "picture",
)

# ─── CSS Selectors for Pricing Sections ──────────────────────────────────────
# When scraping, we first try to find the most relevant section of the page.
# These CSS selectors target elements most likely to contain pricing info.
# [class*='pric'] → any element with "pric" in its class name (e.g., class="pricing-table")
# [class*='plan'] → elements with "plan" in class (e.g., class="plan-card")
# [id*='pric'] → elements with "pric" in their ID
# main → the main content area of the page
# article → article/blog content area
# [role='main'] → ARIA landmark for main content
_PRICING_SELECTORS = (
    "[class*='pric']", "[class*='plan']", "[class*='tier']",
    "[id*='pric']", "[id*='plan']", "[id*='tier']", "main", "article",
    "[role='main']",
)

# ─── Noise Text Patterns ──────────────────────────────────────────────────────
# Lines containing these strings are removed during cleaning.
# These patterns appear on almost every page but have no pricing value.
_NOISE_PATTERNS = (
    "cookie", "privacy policy", "terms of service", "all rights reserved",
    "sign in", "sign up", "log in", "log out", "get started", "contact us",
    "follow us", "© 20", "copyright", "javascript", "please enable",
    "browser not supported", "loading...", "skip to content",
)


# ─────────────────────────────────────────────────────────────────────────────
# CACHE HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _cache_key(url: str) -> str:
    # Create a short, fixed-length string to use as the cache dict key.
    # hashlib.md5(url.encode("utf-8")) → MD5 hash of the URL bytes.
    # usedforsecurity=False → tells Python we're using MD5 for non-security purposes
    #   (Python 3.9+ requires this flag if FIPS mode is enabled on the system).
    # .hexdigest() → returns the hash as a 32-character hex string.
    # Example: "https://stripe.com/pricing" → "a3f9b2c1d4..."
    return hashlib.md5(url.encode("utf-8"), usedforsecurity=False).hexdigest()


def _get_cached(url: str) -> dict | None:
    # Look up a URL's result in the cache.
    # Returns: the cached result dict if found and not expired, or None.
    key = _cache_key(url)          # compute the cache key for this URL
    entry = _CACHE.get(key)        # look up the key in the cache dict
    if not entry:
        return None                # cache miss — not found

    # Check if the cached entry has expired.
    # time.time() → current Unix timestamp (seconds since epoch).
    # entry["cached_at"] → when this entry was stored (also Unix timestamp).
    # If the difference exceeds TTL, the entry is stale.
    if time.time() - entry["cached_at"] > _CACHE_TTL_SECONDS:
        _CACHE.pop(key, None)  # remove the stale entry from cache
        return None            # treat as cache miss

    return entry  # cache hit — return the stored result


def _set_cache(url: str, result: dict) -> None:
    # Store a scrape result in the cache with the current timestamp.
    # {**result, "cached_at": time.time()} → copies all result keys + adds "cached_at".
    # This doesn't modify the original result dict (spread operator creates new dict).
    _CACHE[_cache_key(url)] = {**result, "cached_at": time.time()}


# ─────────────────────────────────────────────────────────────────────────────
# TEXT QUALITY HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _has_pricing_content(text: str) -> bool:
    """Require meaningful length and at least three distinct pricing signals."""
    # Empty or very short text (< 200 chars) is not useful pricing content.
    if not text or len(text.strip()) < 200:
        return False

    # casefold() → aggressive lowercase (handles Unicode variations like "ß" → "ss").
    # Better than .lower() for multilingual content.
    lowered = text.casefold()

    # Count how many pricing keywords appear in the text.
    # sum(...) → counts Trues (each keyword found adds 1).
    # >= 3 → require at least 3 distinct pricing signals to consider it pricing content.
    # WHY 3? Avoids false positives from pages that mention "price" once in a footer.
    return sum(keyword in lowered for keyword in _PRICING_KEYWORDS) >= 3


def _clean_pricing_content(raw_text: str) -> str:
    """Remove duplicated/legal/navigation noise and prioritize pricing lines."""
    pricing_lines: list[str] = []   # lines containing pricing keywords → shown first
    context_lines: list[str] = []   # other useful lines → shown after pricing lines
    seen: set[str] = set()          # track normalized lines to avoid duplicates

    for raw_line in raw_text.splitlines():  # split text into individual lines
        # Collapse multiple whitespace characters into single spaces.
        # re.sub(r"\s+", " ", raw_line) → "hello   world" → "hello world"
        # .strip() → removes leading/trailing whitespace.
        line = re.sub(r"\s+", " ", raw_line).strip()

        # casefold for case-insensitive duplicate detection.
        normalized = line.casefold()

        # Skip lines that are too short (< 3 chars) or already seen.
        if len(line) < 3 or normalized in seen:
            continue

        # Skip lines that contain noise patterns (legal, navigation, etc.)
        if any(pattern in normalized for pattern in _NOISE_PATTERNS):
            continue

        # Skip lines that are ONLY digits, whitespace, or punctuation (1–5 chars).
        # re.fullmatch → must match the ENTIRE string.
        # [\s\d\W]{1,5} → up to 5 chars that are whitespace, digits, or non-word chars.
        # Example: "---", "123", "   " → skipped.
        if re.fullmatch(r"[\s\d\W]{1,5}", line):
            continue

        # Decide which list to put this line into.
        # If it contains any pricing keyword → pricing_lines (shown first in output).
        # Otherwise → context_lines (shown after pricing content).
        target = (
            pricing_lines
            if any(keyword in normalized for keyword in _PRICING_KEYWORDS)
            else context_lines
        )
        target.append(line)   # add the line to the appropriate list
        seen.add(normalized)  # mark this normalized line as seen (dedup)

    # Combine: pricing lines first (most relevant), then context lines.
    # [:_MAX_CLEAN_CHARS] → truncate total output to 8,000 characters.
    return "\n".join([*pricing_lines, *context_lines])[:_MAX_CLEAN_CHARS]


def _focused_bs4_text(soup: BeautifulSoup) -> str:
    """Try pricing-specific CSS selectors first, fall back to full page text."""
    # Try each CSS selector in order of specificity.
    for selector in _PRICING_SELECTORS:
        elements = soup.select(selector)  # find all matching elements
        if not elements:
            continue  # no elements found for this selector → try next

        # Extract text from all matching elements, joined by newlines.
        text = "\n".join(
            element.get_text(separator="\n", strip=True)  # get inner text with newline separators
            for element in elements
        )

        # Check if this section has pricing content.
        if _has_pricing_content(text):
            return text  # this selector found a good pricing section

    # No pricing-specific selector worked — fall back to full page text.
    return soup.get_text(separator="\n", strip=True)


# ─────────────────────────────────────────────────────────────────────────────
# LAYER 1: Static HTTP scraping with requests + BeautifulSoup
# ─────────────────────────────────────────────────────────────────────────────
# SYNC function (called via asyncio.to_thread() in scrape_competitor).
# Works for: plain HTML sites, server-rendered pages (WordPress, Webflow, etc.)
# Fails for: React/Vue/Next.js apps that render content via JavaScript.

def _layer1_sync(url: str) -> dict:
    # Make a synchronous HTTP GET request.
    # timeout=12 → wait up to 12 seconds for a response, then raise Timeout exception.
    # headers=_HEADERS → send browser-like headers to avoid bot detection.
    # allow_redirects=True → follow HTTP 301/302 redirects automatically.
    response = requests.get(
        url,
        timeout=12,
        headers=_HEADERS,
        allow_redirects=True,
    )

    # raise_for_status(): raises requests.HTTPError if status code >= 400.
    # Example: 404 Not Found → raises exception, propagates to caller.
    response.raise_for_status()

    # Parse the HTML response into a BeautifulSoup object.
    # response.text → the HTML as a Python string (decoded from bytes).
    # "html.parser" → Python's built-in parser (no external dependency).
    soup = BeautifulSoup(response.text, "html.parser")

    # Remove all noise tags and their content from the parsed HTML tree.
    # soup.find_all(_NOISE_TAGS) → finds ALL elements matching any noise tag.
    # tag.decompose() → completely removes the tag and its children from the tree.
    for tag in soup.find_all(_NOISE_TAGS):
        tag.decompose()  # e.g., removes all <script>, <style>, <nav>, <footer> tags

    # Extract text from the remaining HTML, preferring pricing sections.
    raw_text = _focused_bs4_text(soup)

    # Check if the extracted text contains sufficient pricing signals.
    if _has_pricing_content(raw_text):
        return {
            "text": raw_text[:_MAX_RAW_CHARS],         # raw text (capped at 12,000 chars)
            "clean_text": _clean_pricing_content(raw_text),  # noise-filtered version
            "status": "success_layer1",                 # tells the caller Layer 1 succeeded
        }

    # Text was too short or didn't have enough pricing keywords.
    return {
        "text": raw_text[:_MAX_RAW_CHARS],  # still return what we got
        "clean_text": "",                    # no clean text (not useful enough)
        "status": "too_short_or_no_pricing", # signals Layer 2 should be tried
    }


# ─────────────────────────────────────────────────────────────────────────────
# LAYER 2: JavaScript-rendered scraping with Playwright (headless Chrome)
# ─────────────────────────────────────────────────────────────────────────────
# ASYNC function. Uses a real Chrome browser instance to render JavaScript.
# Works for: React, Vue, Next.js apps, single-page apps (SPAs).
# Slower: takes 5–40 seconds vs 1–3 seconds for Layer 1.

async def _layer2_playwright(url: str) -> dict:
    # Try to import Playwright — it's an optional dependency.
    # If not installed (e.g., on a minimal deployment), return a "not installed" status.
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return {
            "text": "",
            "clean_text": "",
            "status": "playwright_not_installed",  # tells analysis.py to skip this
        }

    raw_text = ""  # accumulate extracted text here

    # async_playwright(): context manager that initializes Playwright's browser server.
    async with async_playwright() as playwright:
        browser = None  # track browser reference for cleanup in finally block
        try:
            # Launch a headless Chromium browser instance.
            # headless=True → no visible window (runs in background).
            # args → Chrome command-line arguments:
            #   --no-sandbox → required for Linux containers (Docker/Render)
            #   --disable-setuid-sandbox → another sandbox setting for containerized environments
            #   --disable-dev-shm-usage → use /tmp instead of /dev/shm (avoids OOM in Docker)
            #   --disable-blink-features=AutomationControlled → hides Playwright from bot detectors
            browser = await playwright.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-blink-features=AutomationControlled",
                ],
            )

            # Create a new browser context (like an incognito window).
            # user_agent → use our standard browser user agent string.
            # viewport → set screen resolution to 1280×800 (standard laptop).
            # java_script_enabled=True → enable JS execution (that's the whole point of Layer 2).
            context = await browser.new_context(
                user_agent=_HEADERS["User-Agent"],
                viewport={"width": 1280, "height": 800},
                java_script_enabled=True,
            )

            # Open a new page (tab) in this browser context.
            page = await context.new_page()

            # Block images, media, and fonts to save bandwidth and speed up loading.
            # We only need the text content — no need to download images or fonts.
            async def block_heavy_resources(route):
                if route.request.resource_type in {"image", "media", "font"}:
                    await route.abort()   # abort the request (don't download)
                else:
                    await route.continue_()  # allow other requests (JS, CSS, HTML)

            # Register the resource blocker for ALL requests on this page.
            await page.route("**/*", block_heavy_resources)

            # Navigate to the URL.
            # wait_until="domcontentloaded" → wait until basic HTML is loaded (faster than "networkidle").
            # timeout=35_000 → 35 seconds max (some pages are slow to respond).
            await page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=35_000,
            )

            # Wait for the page to become "idle" (no pending network requests).
            # timeout=10,000ms → give it 10 more seconds.
            # WHY separate from goto? JavaScript-heavy apps fetch data AFTER initial HTML load.
            # WHY try/except? Analytics/websocket-heavy sites may never become truly idle.
            try:
                await page.wait_for_load_state("networkidle", timeout=10_000)
            except Exception:
                # Analytics or WebSocket connections may prevent networkidle from ever firing.
                # We continue anyway with whatever has loaded so far.
                pass

            # Extra 2-second buffer for late-loading JavaScript animations and content.
            # Some pricing tables use CSS animations that load after networkidle.
            await page.wait_for_timeout(2_000)  # 2000ms = 2 seconds

            # Try each pricing CSS selector to find the most relevant section.
            for selector in _PRICING_SELECTORS:
                try:
                    # Get the first matching element's inner text.
                    # .first → take only the first match (avoids reading multiple navbars, etc.)
                    # inner_text() → returns visible text (excludes hidden elements).
                    # timeout=3,000ms → 3 seconds max to wait for the element.
                    locator = page.locator(selector).first
                    text = await locator.inner_text(timeout=3_000)
                    if _has_pricing_content(text):
                        raw_text = text  # found a good pricing section
                        break           # stop trying other selectors
                except Exception:
                    continue  # selector failed (element not found) → try next

            if not raw_text:
                # No pricing selector found a good section → fall back to full page body text.
                raw_text = await page.inner_text("body")

        except Exception as error:
            # Any browser/navigation error → return a failed status.
            # str(error)[:100] → limit error message length (some Playwright errors are verbose).
            return {
                "text": "",
                "clean_text": "",
                "status": f"playwright_failed: {str(error)[:100]}",
            }
        finally:
            # ALWAYS close the browser, even if an exception occurred.
            # Not closing leaks a Chrome process — very bad for memory on servers.
            if browser:
                await browser.close()

    # Evaluate what we got from Playwright.
    if _has_pricing_content(raw_text):
        return {
            "text": raw_text[:_MAX_RAW_CHARS],          # raw text capped at 12,000 chars
            "clean_text": _clean_pricing_content(raw_text),  # noise-filtered version
            "status": "success_layer2",                  # tells caller Layer 2 succeeded
        }
    return {
        "text": raw_text[:_MAX_RAW_CHARS],   # return what we got anyway
        "clean_text": "",                     # not useful enough
        "status": "no_pricing_content_after_render",  # even JS rendering didn't help
    }


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API: scrape_competitor
# ─────────────────────────────────────────────────────────────────────────────
# Main entry point called by competitors.py and analysis.py.
# Tries Layer 1, then Layer 2, then gives up gracefully.
# CONNECTED TO: competitors.py calls this in a background task after adding a URL.
#               analysis.py retries failed competitors before running modules.

async def scrape_competitor(url: str) -> dict:
    """Run static scrape, rendered scrape, cleaning, validation, then fallback."""
    # ── Check cache first ─────────────────────────────────────────────────
    # If we've scraped this URL recently, return the cached result.
    # The status gets "_cached" appended to indicate it came from cache.
    cached = _get_cached(url)
    if cached:
        return {
            "text": cached["text"],
            "clean_text": cached["clean_text"],
            "status": f"{cached['status']}_cached",  # e.g., "success_layer1_cached"
        }

    # ── Layer 1: requests (fast, sync) ────────────────────────────────────
    # Run the synchronous Layer 1 function in a thread pool.
    # asyncio.to_thread() → runs blocking code without blocking the event loop.
    try:
        result = await asyncio.to_thread(_layer1_sync, url)
        if result["status"] == "success_layer1":
            _set_cache(url, result)  # cache the successful result
            return result            # return immediately — Layer 1 was enough
        print(f"[Scraper] Layer 1 failed for {url}: {result['status']}")
    except Exception as error:
        # Network error, timeout, 404, etc. → log and proceed to Layer 2.
        print(f"[Scraper] Layer 1 exception for {url}: {error}")

    # ── Layer 2: Playwright (slower, handles JS) ──────────────────────────
    # Only reached if Layer 1 failed or returned insufficient content.
    try:
        result = await _layer2_playwright(url)
        if result["status"] == "success_layer2":
            _set_cache(url, result)  # cache the Playwright result
            return result            # success on Layer 2
        print(f"[Scraper] Layer 2 failed for {url}: {result['status']}")
    except Exception as error:
        print(f"[Scraper] Layer 2 exception for {url}: {error}")

    # ── Both layers failed ────────────────────────────────────────────────
    # Return "manual_required" — the competitor router will store this status.
    # In the frontend, this tells users they need to paste text manually.
    # CONNECTED TO: competitors.py sets scrape_status="manual_required" in DB.
    return {"text": "", "clean_text": "", "status": "manual_required"}


# ─────────────────────────────────────────────────────────────────────────────
# PUBLIC API: scrape_competitors_concurrent
# ─────────────────────────────────────────────────────────────────────────────
# Scrapes multiple competitor URLs simultaneously using asyncio.gather().
# Preserves the original order of the competitors list in the output.
# CONNECTED TO: analysis.py calls this to retry failed competitors before running modules.

async def scrape_competitors_concurrent(
    competitors: list[dict],  # list of dicts, each must have at least a "url" key
) -> list[dict]:
    """Scrape all supplied competitors concurrently while preserving order."""
    # asyncio.gather(): runs all scrape_competitor() coroutines simultaneously.
    # *(scrape_competitor(...) for comp in competitors) → creates N coroutines.
    # return_exceptions=True → don't raise on individual failures; return Exception as a result.
    # WHY return_exceptions=True? One bad URL shouldn't cancel all other scrapes.
    results = await asyncio.gather(
        *(scrape_competitor(comp["url"]) for comp in competitors),
        return_exceptions=True,  # exceptions are returned as values, not raised
    )

    output = []  # build the final result list here
    # zip(competitors, results) → pairs each competitor dict with its scrape result.
    # Order is preserved because gather() returns in the same order as the input.
    for competitor, result in zip(competitors, results):
        if isinstance(result, Exception):
            # This competitor's scrape raised an uncaught exception.
            # Merge the original competitor dict with failure fields.
            output.append(
                {
                    **competitor,   # spread original fields (id, url, name, etc.)
                    "text": "",
                    "clean_text": "",
                    "status": "failed",  # mark as failed
                }
            )
        else:
            # Successful result (or non-exception status like "manual_required").
            # Merge the original competitor dict with the scrape result.
            output.append({**competitor, **result})  # result overrides matching keys

    return output  # list in same order as input competitors
