# ─── database.py ─────────────────────────────────────────────────────────────
# PURPOSE: Sets up the async PostgreSQL database connection for the entire app.
# CONNECTED TO: Every router file (auth, companies, analysis, competitors) uses
#               get_db() as a FastAPI dependency. models.py imports Base from here.
# ─────────────────────────────────────────────────────────────────────────────

# Import async engine factory and async session class from SQLAlchemy.
# "Async" means DB calls don't block the server — other requests can run while waiting.
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

# sessionmaker: a factory that creates Session objects (used to talk to the DB).
# declarative_base: base class that all our database table models (in models.py) inherit from.
from sqlalchemy.orm import sessionmaker, declarative_base

# os: used to read environment variables (like DATABASE_URL from .env file).
import os

# load_dotenv: reads the .env file and puts its key=value pairs into os.environ.
# Without this, os.getenv("DATABASE_URL") would return None.
from dotenv import load_dotenv

# Actually load the .env file so DATABASE_URL is available via os.getenv.
# This runs once when this module is first imported (by main.py on startup).
env_path = os.path.join(os.path.dirname(__file__), ".env")
load_dotenv(env_path, override=True)

# Read the DATABASE_URL from the environment.
# Example value: "postgresql+asyncpg://postgres:Hetvi123@localhost:5432/saas_pricing_db"
# - "postgresql+asyncpg" → use PostgreSQL database with the asyncpg driver (async-compatible)
# - postgres:Hetvi123 → username:password
# - localhost:5432 → host:port
# - saas_pricing_db → database name
# CONNECTED TO: .env file (GROQ_API_KEY, DATABASE_URL are loaded from there)
DATABASE_URL = os.getenv(
    "DATABASE_URL"  # key name in the .env file
)

# Create the async SQLAlchemy engine — the core connection pool to PostgreSQL.
# "engine" is a singleton shared across the whole app — it manages the actual TCP connections.
# echo=False → don't print every SQL query to the console (set True for debugging).
# CONNECTED TO: main.py uses engine.begin() to create tables at startup.
#               AsyncSessionLocal uses engine to get DB connections.
engine = create_async_engine(DATABASE_URL, echo=False)

# Create a "session factory" called AsyncSessionLocal.
# Each time you call AsyncSessionLocal(), you get a new AsyncSession object.
# class_=AsyncSession → use the async version so DB calls are non-blocking.
# expire_on_commit=False → after committing, don't clear the object's attributes
#   (so you can still read model fields after db.commit() without re-querying).
# CONNECTED TO: get_db() uses this to create a session per request.
#               run_full_analysis in analysis.py uses this directly for background tasks.
AsyncSessionLocal = sessionmaker(
    engine,                      # which database to connect to
    class_=AsyncSession,         # use async session (non-blocking)
    expire_on_commit=False        # keep model data accessible after commit
)

# Base is the parent class for all SQLAlchemy models (User, Company, PricingTier, etc.).
# Every model in models.py does: class SomeModel(Base): ...
# Base.metadata.create_all() in main.py uses this to create all tables in the DB.
# CONNECTED TO: models.py imports Base and every model class inherits from it.
#               main.py calls Base.metadata.create_all to auto-create tables.
Base = declarative_base()


# ─── FastAPI Dependency: get_db ───────────────────────────────────────────────
# This is an "async generator" used as a FastAPI dependency.
# Usage in routers: async def some_endpoint(db: AsyncSession = Depends(get_db))
# How it works:
#   1. FastAPI calls get_db() before the endpoint runs.
#   2. "async with AsyncSessionLocal() as session:" opens a DB session.
#   3. "yield session" gives the session to the endpoint function.
#   4. After the endpoint finishes, Python comes back here and the
#      "async with" block closes the session automatically (even on error).
# WHY: This pattern ensures every request gets its own DB session and it's
#      always properly closed — no connection leaks.
# CONNECTED TO: auth.py, companies.py, competitors.py, analysis.py all use
#               Depends(get_db) to receive a DB session in their endpoints.
async def get_db():
    async with AsyncSessionLocal() as session:  # open a new session
        yield session                            # give it to the endpoint
    # session is automatically closed here by the "async with" context manager
