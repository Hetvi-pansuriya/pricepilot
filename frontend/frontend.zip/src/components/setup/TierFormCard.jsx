import { useState } from "react";
import { addTier, updateTier, deleteTier } from "../../api/tiers";
import Card from "../common/Card";
import Input from "../common/Input";
import Button from "../common/Button";
import Badge from "../common/Badge";
import ErrorBanner from "../common/ErrorBanner";
import FeatureTagInput from "./FeatureTagInput";
export default function TierFormCard({
  companyId,
  tier,
  industry,
  onSaved,
  onDeleted,
}) {
  const [v, setV] = useState({
      name: tier.name || "",
      price: tier.price ?? "",
      billing_cycle: tier.billing_cycle || "monthly",
      user_count: tier.user_count ?? "",
      churn_rate: tier.churn_rate ?? "",
    }),
    [saved, setSaved] = useState(!!tier.id),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const set = (e) => setV({ ...v, [e.target.name]: e.target.value });
  const save = async () => {
    if (!v.name || Number(v.price) < 0 || Number(v.user_count) < 0)
      return setError("Please enter valid tier details");
    setBusy(true);
    try {
      const body = {
        ...v,
        price: Number(v.price),
        user_count: Number(v.user_count),
        churn_rate: v.churn_rate === "" ? null : Number(v.churn_rate),
      };
      const d = tier.id
        ? await updateTier(companyId, tier.id, body)
        : await addTier(companyId, body);
      setSaved(true);
      onSaved(d);
    } catch (e) {
      setError(e.detail);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Card className="stack">
      <div className="row-between">
        <h3>{v.name || "New tier"}</h3>
        {saved && <Badge variant="success">✓ Saved</Badge>}
      </div>
      <ErrorBanner message={error} />
      <div className="grid-2">
        <Input
          label="Tier name"
          name="name"
          value={v.name}
          onChange={set}
          required
        />
        <Input
          label="Price"
          type="number"
          min="0"
          name="price"
          value={v.price}
          onChange={set}
        />
        <div className="form-field">
          <label>Billing cycle</label>
          <select name="billing_cycle" value={v.billing_cycle} onChange={set}>
            <option value="monthly">Monthly</option>
            <option value="annual">Annual</option>
          </select>
        </div>
        <Input
          label="User count"
          type="number"
          min="0"
          name="user_count"
          value={v.user_count}
          onChange={set}
        />
        <Input
          label="Churn rate"
          type="number"
          min="0"
          max="1"
          step="0.01"
          name="churn_rate"
          value={v.churn_rate}
          onChange={set}
          hint="Optional, between 0 and 1"
        />
      </div>
      <div className="row">
        <Button loading={busy} onClick={save}>
          Save Tier
        </Button>
        <Button
          variant="danger"
          onClick={async () => {
            if (tier.id) await deleteTier(companyId, tier.id);
            onDeleted(tier.id || tier._key);
          }}
        >
          {tier.id ? "Delete Tier" : "Remove Unsaved Tier"}
        </Button>
      </div>
      {tier.id && (
        <FeatureTagInput
          companyId={companyId}
          tierId={tier.id}
          industry={industry}
          initial={tier.features || []}
        />
      )}
    </Card>
  );
}
