import Card from "../common/Card";
import Badge from "../common/Badge";
export default function CompetitorTable({ module }) {
  const b = module?.benchmark;
  if (!b || module.error)
    return (
      <Card>
        <p>No competitor data — add competitors and re-run</p>
      </Card>
    );
  return (
    <Card className="stack">
      <div className="row-between">
        <h2>Market Benchmark</h2>
        <Badge
          variant={
            b.positioning === "underpriced"
              ? "success"
              : b.positioning === "overpriced"
                ? "danger"
                : "info"
          }
        >
          {b.positioning}
        </Badge>
      </div>
      <p>{b.price_vs_market}</p>
      <div>
        <h3>Features we're missing</h3>
        {(b.features_we_lack || []).map((x) => (
          <p className="danger" key={x}>
            × {x}
          </p>
        ))}
      </div>
      <div>
        <h3>Features we uniquely offer</h3>
        {(b.features_we_uniquely_have || []).map((x) => (
          <p className="success" key={x}>
            ✓ {x}
          </p>
        ))}
      </div>
    </Card>
  );
}
